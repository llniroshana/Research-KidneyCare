var express = require("express");
var router = express.Router();
const auth = require("../authentication/Auth");
const jwt = require("jsonwebtoken");
const axios = require("axios");
const fs = require("fs");
//DB models
const User = require("../schemas/User");
//JWT
const accessTokenSecret = process.env.TOKEN_SECRET;

/* GET users listing. */
router.post("/login", async function (req, res) {
  const user = await User.findOne({
    email: req.body.email,
    password: req.body.password,
  });

  if (user) {
    // Generate an access token
    const accessToken = jwt.sign(
      { id: user._id, role: user.utype },
      accessTokenSecret
    );

    res.json({
      accessToken,
    });
  } else {
    res.json({ error: "Username or password incorrect" });
  }
});

router.post("/register", async function (req, res, next) {
  const validEmail = await User.findOne({ email: req.body.email });
  if (validEmail) {
    return res.json({
      error: "This Email is already registered in the system",
    });
  }
  User.create({
    utype: req.body.uType,
    name: req.body.name,
    phone: req.body.phone,
    email: req.body.email,
    password: req.body.password,
  })
    .then(function (item) {
      res.send(item);
    })
    .catch(next);
});

//user profile update
router.put("/register", function (req, res, next) {
  User.findByIdAndUpdate(
    { _id: req.body.id },
    {
      name: req.body.name,
      email: req.body.email,
      tel: req.body.tel,
      password: req.body.password,
    }
  ).then(function () {
    User.findOne({ _id: req.body.id }).then(function (single) {
      res.send(single);
    });
  });
});

//user profile aditional update
// router.put("/register-additional", function (req, res, next) {
//   User.findByIdAndUpdate(
//     { _id: req.body.id },
//     {
//       user_data: {
//         gender: req.body.gender,
//         age_group: req.body.age_group,
//         marital_stat: req.body.marital_stat,
//         ethnacity: req.body.ethnacity,
//         hometown: req.body.hometown,
//         al_stream: req.body.al_stream,
//         sub_1: req.body.sub_1,
//         res_1: req.body.res_1,
//         sub_2: req.body.sub_2,
//         res_2: req.body.res_2,
//         sub_3: req.body.sub_3,
//         res_3: req.body.res_3,
//         univercity: req.body.univercity,
//         degree: req.body.degree,
//         duration: req.body.duration,
//         grad_year: req.body.grad_year,
//         gpa: req.body.gpa,
//       },
//     }
//   ).then(function () {
//     User.findOne({ _id: req.body.id }).then(function (single) {
//       res.send(single);
//     });
//   });
// });

//initial CKD-Rural-dulitha predictions database save
router.put("/add-ckd", function (req, res, next) {
  console.log(req.body);
  //formatting date
  let date_ob = new Date();
  let formattedDate = date_ob.toLocaleString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

  User.findByIdAndUpdate(
    { _id: req.body.id },
    {
      $push: {
        prediction_history_ckdrural: {
          initial_Prediction: req.body.data.result.Probability_of_having_CKD,
          province: req.body.data.province,
          ageGroup: req.body.data.ageGroup,
          gender: req.body.data.gender,
          bloodSugarLevel: req.body.data.bloodSugarLevel,
          bloodPresureLevel: req.body.data.bloodPresureLevel,
          resource: req.body.data.resource,
          alcohol: req.body.data.alcohol,
          field: req.body.data.field,
          skin: req.body.data.skin,
          urine: req.body.data.urine,
          forming: req.body.data.forming,
          eyes: req.body.data.eyes,
          appatite: req.body.data.appatite,
          cramps: req.body.data.cramps,
          filter: req.body.data.filter,
          itching: req.body.data.itching,
          urination: req.body.data.urination,
          chemicals: req.body.data.chemicals,
          pain: req.body.data.pain,
          eyecolour: req.body.data.eyecolour,
          time: formattedDate,
        },
      },
    }
  ).then(function (single) {
    User.findOne({ _id: req.body.id }).then(function (single) {
      res.send(single);
    });
  });
});
//Thinusha
router.put("/add-ckddiabetes", function (req, res, next) {
  console.log(req.body.data)
  //formatting date
  let date_ob = new Date();
  let formattedDate = date_ob.toLocaleString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

  User.findByIdAndUpdate(
    { _id: req.body.id },
    {
      $push: {
        prediction_history_ckddiabetes: {
          initial_Prediction3: req.body.data.result.Probability_of_having_Diabetes,
          dtype: req.body.data.dtype,
          ageGroup: req.body.data.ageGroup,
          gender: req.body.data.gender,
          bmi: req.body.data.bmi,
          hypertension: req.body.data.hypertension,
          duration: req.body.data.duration,
          history1: req.body.data.history1,
          smoking: req.body.data.smoking,
          fastbloodsugar: req.body.data.fastbloodsugar,
          urinelevel: req.body.data.urinelevel,
          albumin: req.body.data.albumin,
          ckd: req.body.data.ckd,
          bloodSugarLevel: req.body.data.bloodSugarLevel,
          thirsty: req.body.data.thirsty,
          highbloodpressure: req.body.data.highbloodpressure,
          shortbreath: req.body.data.shortbreath,
          appatite: req.body.data.appatite,
          dbloodpressure: req.body.data.dbloodpressure,
          sbloodpressure: req.body.data.sbloodpressure,
          time: formattedDate,
        },
      },
    }
  ).then(function (single) {
    User.findOne({ _id: req.body.id }).then(function (single) {
      res.send(single);
    });
  });
});
// chamara
router.put("/add-ckdelder", function (req, res, next) {
  //formatting date
  let date_ob = new Date();
  let formattedDate = date_ob.toLocaleString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

  User.findByIdAndUpdate(
    { _id: req.body.id },
    {
      $push: {
        prediction_history_ckdelder: {
          initial_Prediction1: req.body.data.result.final_status,
          gender: req.body.data.gender,
          age: req.body.data.age,
          gender: req.body.data.gender,
          kidney_period: req.body.data.kidney_period,
          blood_pressure: req.body.data.blood_pressure,
          nausea: req.body.data.nausea,
          vomit: req.body.data.vomit,
          loss_of_appetite: req.body.data.loss_of_appetite,
          itching: req.body.data.itching,
          hiccups: req.body.data.hiccups,
          metallic_taste: req.body.data.metallic_taste,
          fatigue: req.body.data.fatigue,
          Sleeping_difficulty: req.body.data.Sleeping_difficulty,
          urinate_change: req.body.data.urinate_change,
          mental_sharpness: req.body.data.mental_sharpness,
          muscle_twitches: req.body.data.muscle_twitches,
          swelling: req.body.data.swelling,
          hypertension: req.body.data.hypertension,
          time: formattedDate,
        },
      },
    }
  ).then(function (single) {
    User.findOne({ _id: req.body.id }).then(function (single) {
      res.send(single);
    });
  });
});
//Imali
router.put("/add-ckdtransplant", function (req, res, next) {
  //formatting date
  let date_ob = new Date();
  let formattedDate = date_ob.toLocaleString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

  User.findByIdAndUpdate(
    { _id: req.body.id },
      {
      $push: {
        prediction_history_ckdtransplant: {
          initial_Prediction2: req.body.data.result.critical,
          Gender: req.body.data.Gender,
          TimeDu: req.body.data.TimeDu,
          Flu: req.body.data.Flu,
          chills: req.body.data.chills,
          Body_aches: req.body.data.Body_aches,
          dizziness: req.body.data.dizziness,
          headache: req.body.data.headache,
          itching: req.body.data.itching,
          fever: req.body.data.fever,
          urinating_less: req.body.data.urinating_less,
          blood_in_urine: req.body.data.blood_in_urine,
          urine_color_change: req.body.data.urine_color_change,
          blood_pressure: req.body.data.blood_pressure,
          blood_sugar: req.body.data.blood_sugar,
          weight_gain: req.body.data.weight_gain,
          ankle_swelling: req.body.data.ankle_swelling,
          Pain: req.body.data.Pain,
          tired: req.body.data.tired,
          difficulties_sleeping: req.body.data.difficulties_sleeping,
          fatigue: req.body.data.fatigue,
          eye_color: req.body.data.eye_color,
          loss_of_appetite: req.body.data.loss_of_appetite,
          difficulty_breathing: req.body.data.difficulty_breathing,
          time: formattedDate,
        },
      },
    }
  ).then(function (single) {
    User.findOne({ _id: req.body.id }).then(function (single) {
      res.send(single);
    });
  });
});

// career progression predictions database save
router.put("/progression-results", function (req, res, next) {
  console.log(req.body);
  //formatting date

  let date_ob = new Date();

  let formattedDate = date_ob.toLocaleString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

  User.findByIdAndUpdate(
    { _id: req.body.id },
    {
      $push: {
        carrier_progression_history: {
          career_progression: req.body.carPro,
          salray_progression: req.body.salPro,
          time: formattedDate,
        },
      },
    }
  ).then(function (single) {
    User.findOne({ _id: req.body.id }).then(function (single) {
      res.send(single);
    });
  });
});

//Forget Password
router.post("/forget", async function (req, res, next) {
  // const user = User.findOneAndUpdate({ email: req.body.email });
  const passNew = genPassword();
  User.findOneAndUpdate(
    { email: req.body.email },
    { $set: { password: passNew } }
  ).then((user) => {
    res.json(user);
  });

  axios
    .post("https://form-to-email-api.herokuapp.com/api/email", {
      name: "Career Development",
      receiver: req.body.email,
      subject: "Your Password Has been reset",
      data: [
        {
          field: "Use Your New Password to login to the system",
          value: passNew,
        },
        {
          field: "Thank You!",
          value: "This is System Generated Email Please Do not Reply",
        },
      ],
    })
    .then((res) => {
      console.log(`statusCode: ${res.statusCode}`);
      console.log(res);
    })
    .catch((error) => {
      console.error(error);
    });
});

//Find user id from
router.get("/register/:Cid", auth, function (req, res, next) {
  const userId = req.params.Cid;
  User.findOne({ _id: userId }).then(function (item) {
    res.send(item);
  });
});

//Find user id from name
router.post("/register/user", function (req, res, next) {
  User.find({ _id: req.body.id }).then(function (item) {
    res.send(item);
  });
});

function genPassword() {
  var result = "";
  var characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  var charactersLength = characters.length;
  for (var i = 0; i < 8; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

//Dulitha final prediction details put 
router.get("/latest-ckd-prediction/:Cid", auth, function (req, res, next) {
  const userId = req.params.Cid;
  User.findOne({ _id: userId }).then(function (item) {
    let lastobj =
      item.prediction_history_ckdrural[
        item.prediction_history_ckdrural.length - 1
      ];
    console.log(lastobj);
    res.send(lastobj);
  });
});

//Thinusha
router.get("/latest-ckd-prediction-diabetes/:Cid", auth, function (req, res, next) {
  const userId = req.params.Cid;
  User.findOne({ _id: userId }).then(function (item) {
    let lastobj =
      item.prediction_history_ckddiabities[
        item.prediction_history_ckddiabities.length - 1
      ];
    console.log(lastobj);
    res.send(lastobj);
  });
});

//Chamara
router.get("/latest-ckd-prediction-elder/:Cid", auth, function (req, res, next) {
  const userId = req.params.Cid;
  User.findOne({ _id: userId }).then(function (item) {
    let lastobj =
      item.prediction_history_ckdelder[
        item.prediction_history_ckdelder.length - 1
      ];
    console.log(lastobj);
    res.send(lastobj);
  });
});

//Imali
router.get("/latest-ckd-prediction-transplant/:Cid", auth, function (req, res, next) {
  const userId = req.params.Cid;
  User.findOne({ _id: userId }).then(function (item) {
    let lastobj =
      item.prediction_history_ckdtransplant[
        item.prediction_history_ckdtransplant.length - 1
      ];
    console.log(lastobj);
    res.send(lastobj);
  });
});

//User image upload
const multer = require("multer");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + file.originalname);
  },
});

const Imagfilter = (req, file, cb) => {
  if (
    file.mimetype === "image/jpeg" ||
    file.mimetype === "image/png" ||
    file.mimetype === "image/jpg"
  ) {
    cb(null, true);
  } else {
    cb(null, false);
  }
};

const ImageUpload = multer({
  storage: storage,
  limits: { fileSize: 8194304 },
  fileFilter: Imagfilter,
});

router.put(
  "/user-image",
  ImageUpload.fields([{ name: "userImg", maxCount: 1 }]),
  (req, res, next) => {
    if (req.body.previousImg != "") {
      console.log("./" + req.body.previousImg);
      fs.unlink("./" + req.body.previousImg, function (res) {
        console.log("Previous image deleted");
      });
    }
    User.findByIdAndUpdate(
      { _id: req.body.userID },
      {
        userImage: req.files["userImg"][0].path.replace("\\", "/"),
      }
    )
      .then(function () {
        User.findOne({ _id: req.body.userID }).then(function (single) {
          res.setTimeout(1500, function () {
            res.send(single);
          });
        });
      })
      .catch((error) => {
        res.send(error);
        console.log(error);
      });
  }
);

module.exports = router;
