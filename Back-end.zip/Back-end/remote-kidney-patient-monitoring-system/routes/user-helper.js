var express = require('express');
var router = express.Router();
const User = require('../schemas/User');

// get all users
router.get('/', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    res.json({ message: err });
  }
});

// get user by id
router.get('/:userId', async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    res.json(user);
  } catch (err) {
    res.json({ message: err });
  }
});

// update a user
router.patch('/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const updates = req.body;
        const options = {new: true}
       
        const updatedUser = await User.findByIdAndUpdate(userId, updates, options);
        res.json(updatedUser);
      } catch (err) {
        res.json({ message: err });
      }
});

module.exports = router;
