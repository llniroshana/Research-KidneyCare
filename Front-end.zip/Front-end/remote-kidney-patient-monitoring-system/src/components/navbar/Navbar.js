import React, { useEffect, useState } from "react";
import Model from "../Model";
import Auth from "../../authentication/Auth";
import { useHistory } from "react-router-dom";
export default function Navbar() {
  const history = useHistory();
  const auth = Auth.getUserId();
  //variables
  const [userName, setUser] = useState(undefined);
  const [currentFileShow, setCurrentFileShow] = useState(undefined);

  const [userLevel, setUserLevel] = useState('');

  useEffect(() => {
    if (auth) {
      loadUser();
      setUserLevel(Auth.getUserLevel());
    }

  }, [auth]);

  const loadUser = async () => {
    fetch(`${process.env.REACT_APP_HOSTING_URL}/users/register/` + Auth.getUserId(), {
      method: "GET",
      headers: new Headers({
        Accept: "application/vnd.github.cloak-preview",
        token: Auth.getToken(),
      }),
    })
      .then((res) => res.json())
      .then((response) => {
        console.log(response);
        setUser(response.name);
        if (response.userImage != null) {
          setCurrentFileShow(`${process.env.REACT_APP_HOSTING_URL}/` + response.userImage);
        }
      })
      .catch((error) => console.log(error));
  };
  //model
  const [model, setModel] = useState(null);
  const returnModel = (show, body, confirmation, callback) => {
    setModel(
      <Model
        show={show}
        confirmation={confirmation}
        body={body}
        handleClose={() => {
          returnModel(false, "", null);
        }}
        handleClick={(e) => {
          callback(e);
          returnModel(false, "", null);
        }}
      />
    );
  };
  return (
    <>
      <header class="header">
        {model}
        <nav class="navbar navbar-expand-lg header-nav">
          <div class="navbar-header">
            <a id="mobile_btn" href="javascript:void(0);">
              <span class="bar-icon">
                <span></span>
                <span></span>
                <span></span>
              </span>
            </a>
            <a href="/home" class="navbar-brand logo">
              <img
                src={`${process.env.PUBLIC_URL}/assets/img/kk.png`}
                class="img-fluid"
                alt="Logo"
              />
            </a>
          </div>
          <div class="main-menu-wrapper">
            <div class="menu-header">
              <a href="/home" class="menu-logo">
                <img
                  src="assets/img/kidney care.png"
                  class="img-fluid"
                  alt="Logo"
                />
              </a>
              <a id="menu_close" class="menu-close" href="javascript:void(0);">
                <i class="fas fa-times"></i>
              </a>
            </div>
            <ul class="main-nav">
              <li class="active">
                <a href="/home">Home</a>
              </li>
              
              {userLevel === 'Doctor' ? (
              <li class="has-submenu">
                <a href="">
                  Doctors <i class="fas fa-chevron-down"></i>
                </a>
                <ul class="submenu">
                  <li>
                    <a href="/DoctorDashboard">Doctor Dashboard</a>
                  </li>
                </ul>
              </li>
              ): ''}
               {userLevel === 'Patient' ? (
              <li class="has-submenu">
                <a href="SearchDoctor">
                  Doctors
                </a>

              </li>
              ): ''}
              {userLevel === 'Patient' ? (
              <li class="has-submenu">
                <a href="">
                  Patients <i class="fas fa-chevron-down"></i>
                </a>
                
                <ul class="submenu">
                  <li class="has-submenu">

                  </li>

                  <li>
                    <a href="/patient_profile">Patients Profile</a>
                  </li>
                 
                 
                  
                </ul>
              </li>
              ) : ''}
              <li class="">
                <a href="/hospital">Hospitals</a>
              </li>
            </ul>
          </div>
          <ul class="nav header-navbar-rht">
            {Auth.isAuthenticated() ? (
              <li class="nav-item dropdown has-arrow logged-item">
                <a
                  href="#"
                  class="dropdown-toggle nav-link"
                  data-toggle="dropdown"
                >
                  <span class="user-img">
                    <img
                      class="rounded-circle"
                      src={
                        currentFileShow
                          ? currentFileShow
                          : `https://avatars.dicebear.com/api/identicon/` + userName?.split(" ")[0] + `.svg?mood[]=happy`
                      }
                      width="31"
                      alt="Kalen Chavez"
                    />
                  </span>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                  <div class="user-header">
                    <div class="avatar avatar-sm">
                      <img
                        src={
                          currentFileShow
                            ? currentFileShow
                            : `https://avatars.dicebear.com/api/identicon/` + userName?.split(" ")[0] + `.svg?mood[]=happy`
                        }

                        alt="User Image"
                        class="avatar-img rounded-circle"
                      />
                    </div>
                    <div class="user-text">
                      <h6>{userName?.split(" ")[0]}</h6>
                      <p class="text-muted mb-0">{Auth.getUserLevel() ? Auth.getUserLevel() : null}</p>
                    </div>
                  </div>
                  <a class="dropdown-item" href="/patient_dashboard">
                    Dashboard
                  </a>
                  <a class="dropdown-item" href onClick={() => {
                    returnModel(
                      true,
                      "Do you really want to Logout!",
                      true,
                      function (ans) {
                        if (ans) {
                          Auth.logout((res) => {
                            if (res) {
                              setUser(null);
                              history.push("/");
                            }
                          });
                        }
                      }
                    );
                  }}>
                    Logout
                  </a>
                </div>
              </li>
            ) : (
              <li class="nav-item">
                <a class="nav-link header-login" href="/login">
                  login / Signup{" "}
                </a>
              </li>
            )}
          </ul>
        </nav>
      </header>
    </>
  );
}
