import logo from "./logo.svg";
import "./App.css";
import { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
  Link,
} from "react-router-dom";
import Home from "./pages/Home";
import Footer from "./components/footer/Footer";
import Navbar from "./components/navbar/Navbar";
import PageOne from "./pages/PageOne";
import PageTwo from "./pages/PageTwo";
import PageThree from "./pages/PageThree";
import PageFour from "./pages/PageFour";
import Sidebar from "./components/adminSidebar/Sidebar";
import Blank from "./pages/Blank";
import ReportView from "./pages/reportView/ReportView";
import Login from "./pages/Login";
import Register from "./pages/Register";
import DoctorRegister from "./pages/DoctorRegister";
import PatientProfile from "./pages/PatientProfile";
import PatientDashboard from "./pages/PatientDashboard";
import ReportViewDiabetes from "./pages/reportView/ReportViewDiabetes";
import ReportViewThree from "./pages/reportView/ReportViewThree";
import ReportViewFour from "./pages/reportView/ReportViewFour";
import DoctorDashboard from "./pages/DoctorDashboard";
import DoctorProfile from "./pages/DoctorProfile";
import SearchDoctor from "./pages/SearchDoctor";

import Hospital from "./pages/Hospital";
// ReactDOM.render(<Hospitals/>, document.getElementById('root'));
function App() {
  const [reportData, setReportData] = useState('')


  return (
    <Router>
      <Switch>
        {/* <Route path="/sp/:id">
            <NavBar />
            <SingleProduct />
          </Route> */}
        {/* <Route path="/sp/:id" component={SingleProduct} /> */}

        {/* <Route path="/managemembers/:type">
       <Navbar /> 
        <ViewMembers />
      </Route> */}
        <Route path="/" exact>
          <Navbar />
          <Home />
          <Footer />
        </Route>
        <Route path="/admin/:sidebarItem">
          {/* <Navbar /> */}
          <Sidebar />
          {/* <Footer /> */}
        </Route>
        <Route path="/page1" exact >
          <Navbar />
          <PageOne setReportData={setReportData} />
          <Footer />
        </Route>

        <Route path="/page2">
          <Navbar />
          <PageTwo setReportData={setReportData} />
          <Footer />
        </Route>
        <Route path="/home">
          <Navbar />
          <Home />
          <Footer />
        </Route>
        <Route path="/blank">
          <Navbar />
          <Blank />
          <Footer />
        </Route>
        <Route path="/reportview" >
          <Navbar />
          <ReportView reportData={reportData} />
          <Footer />
        </Route>
        <Route path="/page3" exact >
          <Navbar />
          <PageThree setReportData={setReportData} />
          <Footer />
        </Route>
        <Route path="/page4" exact >
          <Navbar />
          <PageFour setReportData={setReportData} />
          <Footer />
        </Route>
        <Route path="/login">
          <Navbar />
          <Login />
          <Footer />
        </Route>
        <Route path="/register">
          <Navbar />
          <Register />
          <Footer />
        </Route>
        <Route path="/SearchDoctor">
          <Navbar />
          <SearchDoctor />
          <Footer />
        </Route>
        <Route path="/docregister">
          <Navbar />
          <DoctorRegister />
          <Footer />
        </Route>
        <Route path="/patient_profile">
          <Navbar />
          <PatientProfile />
          <Footer />
        </Route>
        <Route path="/patient_dashboard">
          <Navbar />
          <PatientDashboard />
          <Footer />
        </Route>
        <Route path="/DoctorDashboard">
          <Navbar />
          <DoctorDashboard />
          <Footer />
        </Route>
        <Route path="/DoctorProfile">
          <Navbar />
          <DoctorProfile />
          <Footer />
        </Route>
        <Route path="/reportviewdiabetes" >
          <Navbar />
          <ReportViewDiabetes reportData={reportData} />
          <Footer />
        </Route>
        <Route path="/reportviewthree" >
          <Navbar />
          <ReportViewThree reportData={reportData} />
          <Footer />
        </Route>
        <Route path="/reportviewfour" >
          <Navbar />
          <ReportViewFour reportData={reportData} />
          <Footer />
        </Route>
       
        <Route path="/hospital" >
          <Navbar />
          <Hospital />
          <Footer />
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
