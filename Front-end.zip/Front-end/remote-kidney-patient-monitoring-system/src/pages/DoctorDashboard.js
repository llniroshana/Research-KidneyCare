import React, { useEffect, useState } from 'react';

import {
    BrowserRouter as Router,
    Route,
    Switch,
    Redirect,
    Link,
} from "react-router-dom";

import axios from 'axios';

export default function ReportView(params) {
    const { reportData } = params;
    const [formData, setformData] = useState(null);

    const [patients, setPatients] = useState([]);

    useEffect(() => {
        console.log(reportData);
        setformData(reportData);
    }, [])

    useEffect(() => {
        axios
          .get(`${process.env.REACT_APP_HOSTING_URL}/helper/users`)
          .then((response) => {
              let users = response.data;
            console.log(users);

            users = users.filter((user) => user.utype === 'Patient')

            console.log(users)

            users.forEach((user, index) => {
                if(user.prediction_history_ckddiabetes && user.prediction_history_ckddiabetes.length) {
                    user.prediction_history_ckddiabetes = user.prediction_history_ckddiabetes[user.prediction_history_ckddiabetes.length - 1]
                } else {
                    user.prediction_history_ckddiabetes = null;
                }
             
                if(user.prediction_history_ckdelder && user.prediction_history_ckdelder.length) {
                    user.prediction_history_ckdelder = user.prediction_history_ckdelder[user.prediction_history_ckdelder.length - 1]
                } else {
                    user.prediction_history_ckdelder = null;
                }
                
                if(user.prediction_history_ckdrural && user.prediction_history_ckdrural.length) {
                    user.prediction_history_ckdrural = user.prediction_history_ckdrural[user.prediction_history_ckdrural.length - 1]
                } else {
                    user.prediction_history_ckdrural = null;
                }
     
                if(user.prediction_history_ckdtransplant && user.prediction_history_ckdtransplant.length) {
                    user.prediction_history_ckdtransplant = user.prediction_history_ckdtransplant[user.prediction_history_ckdtransplant.length - 1]
                } else {
                    user.prediction_history_ckdtransplant = null;
                }
            })

            setPatients(users);
          })
          .catch((err) => {
            console.log(err);
          });
      }, []);

    return (
        <>
  
        
        {/* <!-- Breadcrumb --> */} 
        <div class="breadcrumb-bar">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-12 col-12">
                        <nav aria-label="breadcrumb" class="page-breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                            </ol>
                        </nav>
                        <h2 class="breadcrumb-title">Dashboard</h2>
                    </div>
                </div>
            </div>
        </div>
        {/* <!-- /Breadcrumb -->
        
        <!-- Page Content --> */}
        <div class="content">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
                        
                        {/* <!-- Profile Sidebar --> */}
                        <div class="profile-sidebar">
                            <div class="widget-profile pro-widget-content">
                                <div class="profile-info-widget">
                                    <a href="index.html" class="navbar-brand logo">
                                        <img src="assets/img/CKD.png" class="img-fluid" alt="Logo"/>
                                    </a>
                                    
                                </div>
                            </div>
                            <div class="dashboard-widget">
                                <nav class="dashboard-menu">
                                    <ul>
                                        <li class="active">
                                            <a href="doctor-dashboard.html">
                                                <i class="fas fa-columns"></i>
                                                <span>Dashboard</span>
                                            </a>
                                        </li>
                                        {/* <li>
                                            <a href="appointments.html">
                                                <i class="fas fa-calendar-check"></i>
                                                <span>Appointments</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="my-patients.html">
                                                <i class="fas fa-user-injured"></i>
                                                <span>My Patients</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="schedule-timings.html">
                                                <i class="fas fa-hourglass-start"></i>
                                                <span>Schedule Timings</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="invoices.html">
                                                <i class="fas fa-file-invoice"></i>
                                                <span>Invoices</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="reviews.html">
                                                <i class="fas fa-star"></i>
                                                <span>Reviews</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="chat-doctor.html">
                                                <i class="fas fa-comments"></i>
                                                <span>Message</span>
                                                <small class="unread-msg">23</small>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="doctor-profile-settings.html">
                                                <i class="fas fa-user-cog"></i>
                                                <span>Profile Settings</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="social-media.html">
                                                <i class="fas fa-share-alt"></i>
                                                <span>Social Media</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="doctor-change-password.html">
                                                <i class="fas fa-lock"></i>
                                                <span>Change Password</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="index.html">
                                                <i class="fas fa-sign-out-alt"></i>
                                                <span>Logout</span>
                                            </a>
                                        </li> */}
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        {/* <!-- /Profile Sidebar --> */}
                        
                    </div>
                    
                    <div class="col-md-7 col-lg-8 col-xl-9">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card dash-card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-4">
                                                <div class="dash-widget dct-border-rht">
                                                    <div class="circle-bar circle-bar1">
                                                        <div class="circle-graph1" data-percent="75">
                                                            <img src="assets/img/icon-01.png" class="img-fluid" alt="patient"/>
                                                        </div>
                                                    </div>
                                                    <div class="dash-widget-info">
                                                        <h6>Total Patient</h6>
                                                        <h3>1800</h3>
                                                        <p class="text-muted">Till Today</p>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-12 col-lg-4">
                                                <div class="dash-widget dct-border-rht">
                                                    <div class="circle-bar circle-bar2">
                                                        <div class="circle-graph2" data-percent="65">
                                                            <img src="assets/img/icon-02.png" class="img-fluid" alt="Patient"/>
                                                        </div>
                                                    </div>
                                                    <div class="dash-widget-info">
                                                        <h6>Today Patient</h6>
                                                        <h3>260</h3>
                                                        <p class="text-muted">06, Dec 2020</p>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-12 col-lg-4">
                                                <div class="dash-widget">
                                                    <div class="circle-bar circle-bar3">
                                                        <div class="circle-graph3" data-percent="50">
                                                            <img src="assets/img/icon-03.png" class="img-fluid" alt="Patient"/>
                                                        </div>
                                                    </div>
                                                    <div class="dash-widget-info">
                                                        <h6>Appoinments</h6>
                                                        <h3>105</h3>
                                                        <p class="text-muted">06, Aug 2020</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-12 col-lg-12">
                            <div class="doc-slot-list">
                                Today patients Status Documents
                                <a href="javascript:void(0)" class="edit_schedule">
                                    <i class="fa fa-bookmark"></i>
                                </a>
                            </div>
                            <br/>
                            <div class="appointments">
                            
                                {/* <!-- Appointment List --> */}
                                {/* <div class="appointment-list">
                                    <div class="profile-info-widget">
                                        <a href="patient-profile.html" class="booking-doc-img">
                                            <img src="assets/img/repo1.jpg" alt="User Image"/>
                                        </a>
                                        <div class="profile-det-info">
                                            <h3><a href="patient-profile.html">Muneer Vickery</a></h3>
                                            <div class="patient-details">
                                                <h5><i class="far fa-clock"></i> 14 Jun 2020, 10.00 AM</h5>
                                                <h5><i class="fas fa-map-marker-alt"></i> Newyork, United States</h5>
                                                <h5><i class="fas fa-envelope"></i> muneer@example.com</h5>
                                                <h5 class="mb-0"><i class="fas fa-phone"></i> +1 945 778 7475</h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="appointment-action">
                                        <a href="#" class="btn btn-sm bg-info-light" data-toggle="modal" data-target="#appt_details">
                                            <i class="far fa-eye"></i> View
                                        </a>
                                        <a href="javascript:void(0);" class="btn btn-sm bg-success-light">
                                            <i class="fas fa-check"></i> Accept
                                        </a>
                                        <a href="javascript:void(0);" class="btn btn-sm bg-danger-light">
                                            <i class="fas fa-times"></i> Cancel
                                        </a>
                                    </div>
                                </div> */}
                                {/* <!-- /Appointment List -->

                                <!-- Appointment List --> */}
                                
                                {/* {console.log('patinets', patients)} */}
                                {patients.map((patient, index) => {
                                    return (
                                        <div>
                                            {(patient.prediction_history_ckddiabetes && patient.prediction_history_ckddiabetes.initial_Prediction3 === 'Dpresent') ? (
                                                <div class="appointment-list">
                                                    <div class="profile-info-widget">
                                                        <a href="patient-profile.html" class="booking-doc-img">
                                                            <img src="assets/img/repo1.jpg" alt="User Image"/>
                                                        </a>
                                                        <div class="profile-det-info">
                                                            <h3><a href="patient-profile.html">{patient.name}</a></h3>
                                                            <div class="patient-details">
                                                                <h5><i class="fas fa-clipboard-check"></i>Diabetic Mellitus</h5>
                                                                <h5><i class="far fa-bell"></i><span className="badge badge-pill bg-danger-light">Critical</span></h5>
                                                                <h5><i class="far fa-clock"></i>{patient.prediction_history_ckddiabetes.time}</h5>
                                                                <h5><i class="fas fa-map-marker-alt"></i>{patient.city}</h5>
                                                                <h5><i class="fas fa-envelope"></i>{patient.email}</h5>
                                                                <h5 class="mb-0"><i class="fas fa-phone"></i>{patient.phone}</h5>
                                                            </div>
                                                        </div>
                                                    </div>                                          
                                                    <div class="appointment-action">
                                                        <a href="#" class="btn btn-sm bg-info-light" data-toggle="modal" data-target="#appt_details">
                                                            <i class="far fa-eye"></i> View
                                                        </a>
                                                        <a href="javascript:void(0);" class="btn btn-sm bg-success-light">
                                                            <i class="fas fa-check"></i> Accept
                                                        </a>
                                                        <a href="javascript:void(0);" class="btn btn-sm bg-danger-light">
                                                            <i class="fas fa-times"></i> Cancel
                                                        </a>
                                                    </div>
                                                </div>
                                            ) : ''}
                                        </div>
                                    )
                                })}
                       
                                {patients.map((patient, index) => {
                                    return (
                                        <div>
                                            {(patient.prediction_history_ckdelder && patient.prediction_history_ckdelder.initial_Prediction1 === 'Critical Patient') ? (
                                                <div class="appointment-list">
                                                    <div class="profile-info-widget">
                                                        <a href="patient-profile.html" class="booking-doc-img">
                                                            <img src="assets/img/repo1.jpg" alt="User Image"/>
                                                        </a>
                                                        <div class="profile-det-info">
                                                            <h3><a href="patient-profile.html">{patient.name}</a></h3>
                                                            <div class="patient-details">
                                                                <h5><i class="fas fa-clipboard-check"></i>Elderly Patient</h5>
                                                                <h5><i class="far fa-bell"></i><span className="badge badge-pill bg-danger-light">Critical</span></h5>
                                                                <h5><i class="far fa-clock"></i>{patient.prediction_history_ckdelder.time}</h5>
                                                                <h5><i class="fas fa-map-marker-alt"></i>{patient.city}</h5>
                                                                <h5><i class="fas fa-envelope"></i>{patient.email}</h5>
                                                                <h5 class="mb-0"><i class="fas fa-phone"></i>{patient.phone}</h5>
                                                            </div>
                                                        </div>
                                                    </div>                                          
                                                    <div class="appointment-action">
                                                        <a href="#" class="btn btn-sm bg-info-light" data-toggle="modal" data-target="#appt_details">
                                                            <i class="far fa-eye"></i> View
                                                        </a>
                                                        <a href="javascript:void(0);" class="btn btn-sm bg-success-light">
                                                            <i class="fas fa-check"></i> Accept
                                                        </a>
                                                        <a href="javascript:void(0);" class="btn btn-sm bg-danger-light">
                                                            <i class="fas fa-times"></i> Cancel
                                                        </a>
                                                    </div>
                                                </div>
                                            ) : ''}
                                        </div>
                                    )
                                })}

                                {patients.map((patient, index) => {
                                    return (
                                        <div>
                                            {(patient.prediction_history_ckdrural && patient.prediction_history_ckdrural.initial_Prediction === '1') ? (
                                                <div class="appointment-list">
                                                    <div class="profile-info-widget">
                                                        <a href="patient-profile.html" class="booking-doc-img">
                                                            <img src="assets/img/repo1.jpg" alt="User Image"/>
                                                        </a>
                                                        <div class="profile-det-info">
                                                            <h3><a href="patient-profile.html">{patient.name}</a></h3>
                                                            <div class="patient-details">
                                                                <h5><i class="fas fa-clipboard-check"></i>CKD Risk Analysis</h5>
                                                                <h5><i class="far fa-bell"></i><span className="badge badge-pill bg-danger-light">Critical</span></h5>
                                                                <h5><i class="far fa-clock"></i>{patient.prediction_history_ckdrural.time}</h5>
                                                                <h5><i class="fas fa-map-marker-alt"></i>{patient.city}</h5>
                                                                <h5><i class="fas fa-envelope"></i>{patient.email}</h5>
                                                                <h5 class="mb-0"><i class="fas fa-phone"></i>{patient.phone}</h5>
                                                            </div>
                                                        </div>
                                                    </div>                                          
                                                    <div class="appointment-action">
                                                        <a href="#" class="btn btn-sm bg-info-light" data-toggle="modal" data-target="#appt_details">
                                                            <i class="far fa-eye"></i> View
                                                        </a>
                                                        <a href="javascript:void(0);" class="btn btn-sm bg-success-light">
                                                            <i class="fas fa-check"></i> Accept
                                                        </a>
                                                        <a href="javascript:void(0);" class="btn btn-sm bg-danger-light">
                                                            <i class="fas fa-times"></i> Cancel
                                                        </a>
                                                    </div>
                                                </div>
                                            ) : ''}
                                        </div>
                                    )
                                })}

                                {patients.map((patient, index) => {
                                    return (
                                        <div>
                                            {(patient.prediction_history_ckdtransplant && patient.prediction_history_ckdtransplant.initial_Prediction2 === 'Yes') ? (
                                                <div class="appointment-list">
                                                    <div class="profile-info-widget">
                                                        <a href="patient-profile.html" class="booking-doc-img">
                                                            <img src="assets/img/repo1.jpg" alt="User Image"/>
                                                        </a>
                                                        <div class="profile-det-info">
                                                            <h3><a href="patient-profile.html">{patient.name}</a></h3>
                                                            <div class="patient-details">
                                                                <h5><i class="fas fa-clipboard-check"></i>Transpalnt Patient</h5>
                                                                <h5><i class="far fa-bell"></i><span className="badge badge-pill bg-danger-light">Critical</span></h5>
                                                                <h5><i class="far fa-clock"></i>{patient.prediction_history_ckdtransplant.time}</h5>
                                                                <h5><i class="fas fa-map-marker-alt"></i>{patient.city}</h5>
                                                                <h5><i class="fas fa-envelope"></i>{patient.email}</h5>
                                                                <h5 class="mb-0"><i class="fas fa-phone"></i>{patient.phone}</h5>
                                                            </div>
                                                        </div>
                                                    </div>                                          
                                                    <div class="appointment-action">
                                                        <a href="#" class="btn btn-sm bg-info-light" data-toggle="modal" data-target="#appt_details">
                                                            <i class="far fa-eye"></i> View
                                                        </a>
                                                        <a href="javascript:void(0);" class="btn btn-sm bg-success-light">
                                                            <i class="fas fa-check"></i> Accept
                                                        </a>
                                                        <a href="javascript:void(0);" class="btn btn-sm bg-danger-light">
                                                            <i class="fas fa-times"></i> Cancel
                                                        </a>
                                                    </div>
                                                </div>
                                            ) : ''}
                                        </div>
                                    )
                                })}
                      
                                {/* <div class="appointment-list">
                                    <div class="profile-info-widget">
                                        <a href="patient-profile.html" class="booking-doc-img">
                                            <img src="assets/img/repo1.jpg" alt="User Image"/>
                                        </a>
                                        <div class="profile-det-info">
                                            <h3><a href="patient-profile.html">Baldwinn Chen</a></h3>
                                            <div class="patient-details">
                                                <h5><i class="far fa-clock"></i> 4 Nov 2020, 11.00 AM</h5>
                                                <h5><i class="fas fa-map-marker-alt"></i> California, United States</h5>
                                                <h5><i class="fas fa-envelope"></i> baldwinnchen@example.com</h5>
                                                <h5 class="mb-0"><i class="fas fa-phone"></i> +1 319 833 5635</h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="appointment-action">
                                        <a href="#" class="btn btn-sm bg-info-light" data-toggle="modal" data-target="#appt_details">
                                            <i class="far fa-eye"></i> View
                                        </a>
                                        <a href="javascript:void(0);" class="btn btn-sm bg-success-light">
                                            <i class="fas fa-check"></i> Accept
                                        </a>
                                        <a href="javascript:void(0);" class="btn btn-sm bg-danger-light">
                                            <i class="fas fa-times"></i> Cancel
                                        </a>
                                    </div>
                                </div> */}
                                {/* <!-- /Appointment List -->
                                
                                <!-- Appointment List --> */}
                                {/* <div class="appointment-list">
                                    <div class="profile-info-widget">
                                        <a href="patient-profile.html" class="booking-doc-img">
                                            <img src="assets/img/patients/patient11.jpg" alt="User Image"/>
                                        </a>
                                        <div class="profile-det-info">
                                            <h3><a href="patient-profile.html">Jevrem Oshea</a></h3>
                                            <div class="patient-details">
                                                <h5><i class="far fa-clock"></i> 13 Nov 2020, 7.00 PM</h5>
                                                <h5><i class="fas fa-map-marker-alt"></i> Colorado, United States</h5>
                                                <h5><i class="fas fa-envelope"></i> jevremoshea@example.com</h5>
                                                <h5 class="mb-0"><i class="fas fa-phone"></i> +1 303 607 7075</h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="appointment-action">
                                        <a href="#" class="btn btn-sm bg-info-light" data-toggle="modal" data-target="#appt_details">
                                            <i class="far fa-eye"></i> View
                                        </a>
                                        <a href="javascript:void(0);" class="btn btn-sm bg-success-light">
                                            <i class="fas fa-check"></i> Accept
                                        </a>
                                        <a href="javascript:void(0);" class="btn btn-sm bg-danger-light">
                                            <i class="fas fa-times"></i> Cancel
                                        </a>
                                    </div>
                                </div> */}
                                {/* <!-- /Appointment List --> */}
                                
                            </div>
                        </div>
                    
                    </div>
                </div>

            </div>

        </div>		
        {/* <!-- /Page Content --> */}
                                
        </>


    )
}
