import React, { useEffect, useState } from 'react';

import {
    BrowserRouter as Router,
    Route,
    Switch,
    Redirect,
    Link,
} from "react-router-dom";

import Auth from '../authentication/Auth';
import axios from 'axios';

export default function PatientProfile(params) {
    const [user, setUser] = useState('');

    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState('');
    const [bloodGroup, setBloodGroup] = useState('');
    const [email, setEmail] = useState('');
    const [mobile, setMobile] = useState('');
    const [address, setAddress] = useState('');
    const [city, setCity] = useState('');
    const [province, setProvince] = useState('');
    const [postalCode, setPostalCode] = useState('');

    useEffect(() => {
      let userId = Auth.getUserId();

      axios
        .get(`${process.env.REACT_APP_HOSTING_URL}/helper/users/${userId}`)
        .then((response) => {
          console.log(response.data);
          setUser(response.data);

          setFirstName(response.data.name);
          setLastName(response.data.lastName);
          setDateOfBirth(response.data.dateOfBirth);
          setBloodGroup(response.data.bloodGroup);
          setEmail(response.data.email);
          setMobile(response.data.phone);
          setAddress(response.data.address);
          setCity(response.data.city);
          setProvince(response.data.province);
          setPostalCode(response.data.postalCode);
        })
        .catch((err) => {
          console.log(err);
        });
    }, []);

    const handleSave = async (e) => {
        e.preventDefault();
        try {
            let userId = Auth.getUserId();

            let body = {
                "name": firstName ? firstName : '',
                "lastName": lastName ? lastName : '',
                "dateOfBirth": dateOfBirth ? dateOfBirth : '',
                "bloodGroup": bloodGroup ? bloodGroup : '',
                "email": email ? email : '',
                "phone": mobile ? mobile : '',
                "address": address ? address : '',
                "city": city ? city : '',
                "province": province ? province : '',
                "postalCode": postalCode ? postalCode : ''
            }

            console.log(body)
            const user = await axios.patch(`${process.env.REACT_APP_HOSTING_URL}/helper/users/${userId}`, body);
            alert('User details saved!');
            console.log(user);
        } catch (err) {
          console.log(err);
        }
      };

    return (
        <>
            {/* <!-- Breadcrumb --> */}
            <div class="breadcrumb-bar">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-md-12 col-12">
                            <nav aria-label="breadcrumb" class="page-breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="/home">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Blank Page
                                    </li>
                                </ol>
                            </nav>
                            <h2 class="breadcrumb-title">Blank Page</h2>
                        </div>
                    </div>
                </div>
            </div>
            {/* <!-- /Breadcrumb -->    */}

            <div class="content">
                <>
                    {/* <!-- Breadcrumb --> */}
                    <div class="breadcrumb-bar">
                        <div class="container-fluid">
                            <div class="row align-items-center">
                                <div class="col-md-12 col-12">
                                    <nav aria-label="breadcrumb" class="page-breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="/home">Home</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">

                                            </li>
                                        </ol>
                                    </nav>
                                    <h2 class="breadcrumb-title">Patient Profile</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* <!-- /Breadcrumb -->    */}
                </>

                <div class="container-fluid">

                    <div class="row">

                        {/* <!-- Profile Sidebar --> */}
                        <div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
                            <div class="profile-sidebar">
                                <div class="widget-profile pro-widget-content">
                                    <div class="profile-info-widget">
                                        <a href="#" class="booking-doc-img">
                                            <img src="assets/img/ava.jpg" alt="User Image" />
                                        </a>
                                        <div class="profile-det-info">
                                            <h3>{firstName}</h3>
                                            <div class="patient-details">
                                                <h5><i class="fas fa-birthday-cake"></i>{dateOfBirth}</h5>
                                                <h5 class="mb-0"><i class="fas fa-map-marker-alt"></i>{city}</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="dashboard-widget">
                                    <nav class="dashboard-menu">
                                        <ul>
                                            <li>
                                                <a href="/patient_dashboard">
                                                    <i class="fas fa-columns"></i>
                                                    <span>Dashboard</span>
                                                </a>
                                            </li>


                                            <li>
                                                <a href="/patient_profile">
                                                    <i class="fas fa-user-cog"></i>
                                                    <span>Profile Settings</span>
                                                </a>
                                            </li>

                                            <li>
                                                <a href="index.html">
                                                    <i class="fas fa-sign-out-alt"></i>
                                                    <span>Logout</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>

                            </div>
                        </div>
                        {/* <!-- /Profile Sidebar --> */}

                        <div class="col-md-7 col-lg-8 col-xl-9">
                            <div class="card">
                                <div class="card-body">

                                    {/* <!-- Profile Settings Form --> */}
                                    <form>
                                        <div class="row form-row">
                                            <div class="col-12 col-md-12">
                                                <div class="form-group">
                                                    <div class="change-avatar">
                                                        {/* <div class="profile-img">
                                                            <img src="assets/img/patients/patient.jpg" alt="User Image" />
                                                        </div> */}
                                                        <div class="upload-img">
                                                            <div class="change-photo-btn">
                                                                <span><i class="fa fa-upload"></i> Upload Photo</span>
                                                                <input type="file" class="upload" />
                                                            </div>
                                                            <small class="form-text text-muted">Allowed JPG, GIF or PNG. Max size of 2MB</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="form-group">
                                                    <label>First Name</label>
                                                    <input type="text" className="form-control" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="form-group">
                                                    <label>Last Name</label>
                                                    <input type="text" className="form-control" value={lastName} onChange={(e) => setLastName(e.target.value)} />
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="form-group">
                                                    <label>Date of Birth</label>
                                                    <div>
                                                        <input type="date" className="form-control"  value={dateOfBirth} onChange={(e) => setDateOfBirth(e.target.value)}/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="form-group">
                                                    <label>Blood Group</label>
                                                    <select className="form-control select" value={bloodGroup} onChange={(e) => setBloodGroup(e.target.value)}>
                                                        <option>Select</option>
                                                        <option>A1+</option>
                                                        <option>A-</option>
                                                        <option>A+</option>
                                                        <option>B-</option>
                                                        <option>B+</option>
                                                        <option>AB-</option>
                                                        <option>AB+</option>
                                                        <option>O-</option>
                                                        <option>O+</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="form-group">
                                                    <label>Email ID</label>
                                                    <input type="email" className="form-control" value={email} onChange={(e) => setEmail(e.target.value)} />
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="form-group">
                                                    <label>Mobile</label>
                                                    <input type="text" className="form-control" value={mobile} onChange={(e) => setMobile(e.target.value)} />
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <label>Address</label>
                                                    <input type="text" className="form-control" value={address} onChange={(e) => setAddress(e.target.value)} />
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="form-group">
                                                    <label>City</label>
                                                    <input type="text" className="form-control" value={city} onChange={(e) => setCity(e.target.value)} />
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="form-group">
                                                    <label>Province</label>
                                                    <input type="text" className="form-control" value={province} onChange={(e) => setProvince(e.target.value)} />
                                                </div>
                                            </div>
                                            {/* <div class="col-12 col-md-6">
                                                <div class="form-group">
                                                    <label>Postal Code</label>
                                                    <input type="text" className="form-control" value={postalCode} onChange={(e) => setPostalCode(e.target.value)} />
                                                </div>
                                            </div> */}
                                        </div>
                                        <div class="submit-section">
                                            <button type="submit" className="btn btn-primary submit-btn" onClick={(e) => handleSave(e)}>Save Changes</button>
                                        </div>
                                    </form>
                                    {/* <!-- /Profile Settings Form --> */}

                                </div>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </>


    )
}
