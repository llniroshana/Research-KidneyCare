import React, { useEffect, useState } from 'react';
import Auth from "../../authentication/Auth";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
  Link,
} from "react-router-dom";

export default function ReportView(params) {
  const { reportData } = params;
  const [formData, setformData] = useState(null);

  const provinces=["North Central", "North Western","Eastern","Uva","North"]
  const AgeGroup=["10-19", "20-29","30-39","40-49","50-59","60+"]
  const alcohol=["Addicted", "Occasional"," Never"]
  const BloodSugerLevel=["Below 89 mg/dL", "90 -120 mg/d","121-139 mg/dL","140mg/dL+"]
  const BloodPressureLevel=["120 mm Hg", "120 - 139 mm Hg","140 - 159 mm Hg","160 - 179 mm Hg","180 mm Hg+"]
  const WaterResource=["By direct from the Well, River , Lake","Water providing by government (water line)","Purified bottle water (From market)","Tube well"]
  // const Gender =["Male","Female"]
  const checkbox =["No","Yes"]


  const Critical = (criti) => {
    if (criti === "1") {
      return "The health condition is more likely to be at Risk.Please immediately get Nephrology unit medical attention ";
    } else {
      return "The health condition is more likely to be NORMAL";
    }
  }


  useEffect(() => {
    console.log(reportData);
    
    setformData(reportData);
    addResults(reportData);
  }, [])
  
  const addResults = async (reportData) => {
    
    try {
      const requestOptions = {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: Auth.getUserId(),
          data: reportData,
        }),
      };
      const res1 = await fetch(
        `${process.env.REACT_APP_HOSTING_URL}/users/add-ckd`,
        requestOptions
      )
        .then((res) => res.json())
        .then((res) => {
          console.log(res);
        });
    } catch (e) {
        console.log(e);
    }
};
  return (
    <>
      {/* <!-- Breadcrumb --> */}
      <div class="breadcrumb-bar">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-md-12 col-12">
              <nav aria-label="breadcrumb" class="page-breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                    <a href="/home">Home</a>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">
                    Report
                  </li>
                </ol>
              </nav>
              <h2 class="breadcrumb-title">Report</h2>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- /Breadcrumb -->    */}

      <div class="content">
        <>
          {/* <!-- Breadcrumb --> */}
          <div class="breadcrumb-bar">
            <div class="container-fluid">
              <div class="row align-items-center">
                <div class="col-md-12 col-12">
                  <nav aria-label="breadcrumb" class="page-breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item">
                        <a href="/home">Home</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                      CKD Risk Analysis
                      </li>
                    </ol>
                  </nav>
                  <h2 class="breadcrumb-title">Patient Prediction Report</h2>
                </div>
              </div>
            </div>
          </div>
          {/* <!-- /Breadcrumb -->    */}
        </>

        <div class="container-fluid">

          <div class="row">
            <div class="col-lg-8 offset-lg-2">
              <div class="invoice-content">
                <div class="invoice-item">
                  <div class="row">
                    <div class="">
                      <p>
                        <strong style={{fontSize: 18, textAlign :"center"}} >Patient Prediction Report : </strong>
                      </p><br/>
                      <p>
                        <div class="col-md-12 col-xl-12 ">
                          <div class="">
                            <table class="invoice-table-two table">
                               <tbody>
                                {formData && (
                                  
                                  // <div class="alert alert-danger" >
                                    <h4>
                                      {/* Your Prediction - {Critical(formData.result.Probability_of_having_CKD)}{" "} */}
                                      {formData.result.Probability_of_having_CKD === '1' ? 
                                      <span className="alert alert-danger">The health condition is more likely to be at RISK.Please get Nephrology unit medical attention</span> : 
                                      <span className="alert alert-success">The health condition is more likely to be at NORMAL</span>}
                                                                            
                                    </h4>
                                  // </div>

                                 )}
                              </tbody>
                            </table>
                          </div>
                       </div>
                      </p>
                    </div>
                 </div>
                </div>



                {/* <!-- Invoice Item --> */}
                <div class="invoice-item">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="invoice-info">
                      </div>
                    </div>
                  </div>
                </div>
                {/* <!-- /Invoice Item --> */}

                {/* <!-- Invoice Item --> */}
                <div class="invoice-item invoice-table-wrap">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="table-responsive">
                        <table class="invoice-table table table-bordered text-center">
                          
                          <thead>
                            <tr>
                              <th>Description</th>

                              <th>Symptoms Analysis Result</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>
                                <label>Province</label>
                              </td>
                              <td>{provinces[reportData.province]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Age Group</label>
                              </td>
                              <td>{AgeGroup[reportData.ageGroup]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Gender</label>
                              </td>
                              <td>{reportData.gender}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Alcohol</label>
                              </td>
                              <td>{alcohol[reportData.alcohol]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Blood Suger Level</label>
                              </td>
                              <td>{BloodSugerLevel[reportData.bloodSugarLevel]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Blood Pressure Level</label>
                              </td>
                              <td>{BloodPressureLevel[reportData.bloodPresureLevel]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Water Resource</label>
                              </td>
                              <td>{WaterResource[reportData.resource]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Is your home situated near to the paddy fields?</label>
                              </td>
                              <td>{checkbox[reportData.field]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Do you have Sleeping problems?</label>
                              </td>
                              <td>{checkbox[reportData.sleep]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Dry nature of the skin</label>
                              </td>
                              <td>{checkbox[reportData.skin]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Do you Lightly Bleed with urine </label>
                              </td>
                              <td>{reportData.urine}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Foaming while urinating</label>
                              </td>
                              <td>{checkbox[reportData.forming]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>
                                Persistent swelling around the eyes
                                </label>
                              </td>
                              <td>{checkbox[reportData.eyes]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>
                                Decreased appetite
                                </label>
                              </td>
                              <td>{reportData.appatite}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Do you have frequently muscle cramps or muscle twitches</label>
                              </td>
                              <td>{checkbox[reportData.cramps]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>
                                 Usage of filtered and boiled water
                                </label>
                              </td>
                              <td>{checkbox[reportData.filter]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Is there a frequent itching in your skin</label>
                              </td>
                              <td>{checkbox[reportData.itching]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label> Do you have frequent urination necessary</label>
                              </td>
                              <td>{checkbox[reportData.urination]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Do you have a direct connect with agricultural chemicals</label>
                              </td>
                              <td>{checkbox[reportData.chemicals]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Do you have pain around your kidneys</label>
                              </td>
                              <td>{checkbox[reportData.pain]}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Change of eye color (Light yellow)</label>
                              </td>
                              <td>{checkbox[reportData.eyecolour]}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                {/* <!-- /Invoice Item --> */}

                {/* <!-- Invoice Information --> */}
                {/* <div class="other-info">
                  <h4>Attach Medical Reports</h4>
                  <div class="form-group row">
                    <label class="col-form-label col-md-2">File Input</label>
                    <div class="col-md-10">
                      <input class="form-control" type="file" />
                    </div>
                  </div>
                </div>
                {/* <!-- /Invoice Information --> */}
                {/* <div class="col-6 col-sm-4 col-md-2 col-xl mb-3 mb-xl-0 text-right">
                  <Link to="/reportview"><button type="submit" class="btn btn-outline-success active"><i class="fas fa-plane" > </i>
                    Send
                  </button></Link>
                </div> */}

              </div> 

            </div>

          </div>

        </div>


      </div>
    </>


  )
}
