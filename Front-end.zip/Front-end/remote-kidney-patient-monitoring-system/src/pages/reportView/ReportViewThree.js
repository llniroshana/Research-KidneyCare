import React, { useEffect, useState } from 'react';
import Auth from "../../authentication/Auth";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
  Link,
} from "react-router-dom";

export default function ReportViewThree(params) {
  const { reportData } = params;
  const [formData, setformData] = useState(null);

  const criticalElder = (criti) => {
    if (criti === "Critical Patient") {
      return "The health condition is more likely to be at risk.";
    } else {
      return "The health condition is more likely to be normal";
    }
  }

  useEffect(() => {
    console.log(reportData);
    
    setformData(reportData);
    if(reportData!=null){
      addResults(reportData);
    }
    
  }, [])
  
  const addResults = async (reportData) => {
    console.log({reportData})
    try {
      const requestOptions = {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: Auth.getUserId(),
          data: reportData,
        }),
      };
      const res1 = await fetch(
        `${process.env.REACT_APP_HOSTING_URL}/users/add-ckdelder`,
        requestOptions
      )
        .then((res) => res.json())
        .then((res) => {
          console.log(res);
        });
    } catch (e) {
        console.log(e);
    }
};
  return (
    <>
      {/* <!-- Breadcrumb --> */}
      <div class="breadcrumb-bar">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-md-12 col-12">
              <nav aria-label="breadcrumb" class="page-breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                    <a href="/home">Home</a>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">
                    Blank Page
                  </li>
                </ol>
              </nav>
              <h2 class="breadcrumb-title">Blank Page</h2>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- /Breadcrumb -->    */}

      <div class="content">
        <>
          {/* <!-- Breadcrumb --> */}
          <div class="breadcrumb-bar">
            <div class="container-fluid">
              <div class="row align-items-center">
                <div class="col-md-12 col-12">
                  <nav aria-label="breadcrumb" class="page-breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item">
                        <a href="/home">Home</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                      Elderly Patient
                      </li>
                    </ol>
                  </nav>
                  <h2 class="breadcrumb-title">Patient Prediction Report</h2>
                </div>
              </div>
            </div>
          </div>
          {/* <!-- /Breadcrumb -->    */}
        </>

        <div class="container-fluid">

          <div class="row">
            <div class="col-lg-8 offset-lg-2">
              <div class="invoice-content">
                <div class="invoice-item">
                  <div class="row">

                    <div class="col-md-5">

                      <div class="invoice-logo">

                        <img src="assets/img/k4.png" alt="logo" />

                      </div>


                    </div>
                    <div class="">
                      <p class="invoice-details">
                     </p>
                    </div>


                  </div>
                </div>



                {/* <!-- Invoice Item --> */}
                {/* <div class="invoice-item">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="invoice-info">

                        <p class="invoice-details">

                        <div class="col-md-12 ">
                      <div class="table-responsive">
                        <table class="">
                          <tbody>
                            {formData && (
                              <div class="alert alert-danger alert-dismissible">
                                <h6>
                                  <i class="icon fa fa-check"></i> Final Result - {criticalElder(formData.result.final_status)}{" "}
                                </h6>
                              </div>
                            )}
                          </tbody>

                        </table>
                      </div>
                    </div>
                        </p>
                      </div>
                    </div>
                  </div>
                </div> */}
                <div class="invoice-item">
                  <div class="row">
                    <div class="">
                      <p>
                        <strong style={{fontSize: 18, textAlign :"center"}} >Patient Prediction Report : </strong>
                      </p><br/>
                      <p>
                        <div class="col-md-12 col-xl-12 ">
                          <div class="">
                            <table class="invoice-table-two table">
                               <tbody>
                                {formData && (
                                  
                                
                                    <h4>
                                      
                                      {formData.result.final_status === 'Critical Patient' ? 
                                      <span className="alert alert-danger">The health condition is more likely to be at RISK.Please get Nephrology unit medical attention</span> : 
                                      <span className="alert alert-success">The health condition is more likely to be at NORMAL</span>}
                                                                            
                                    </h4>
                                  

                                 )}
                              </tbody>
                            </table>
                          </div>
                       </div>
                      </p>
                    </div>
                 </div>
                </div>

                {/* <!-- /Invoice Item --> */}

                {/* <!-- Invoice Item --> */}
                <div class="invoice-item invoice-table-wrap">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="table-responsive">
                        <table class="invoice-table table table-bordered text-center">
                          <thead>
                            <tr>
                              <th>Description</th>
                              
                              <th>Symptoms Analysis Result</th>

                          </tr>
                          </thead>
                          <tbody>
                          <tr>
                          <td>
                          <label>Gender</label>
                          </td>
                          <td>{reportData.gender}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Age</label>
                          </td>
                          <td>Type {reportData.age}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Kidney Period</label>
                          </td>
                          <td>{reportData.kidney_period}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Blood Pressure Level</label>
                          </td>
                          <td>{reportData.blood_pressure}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Do you have frequent nausea?</label>
                          </td>
                          <td>{reportData.nausea}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Do you have frequent vomit?</label>
                          </td>
                          <td>{reportData.vomit}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Do you have a loss of appetite?</label>
                          </td>
                          <td>{reportData.loss_of_appetite}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Is there a persistent itching in your skin?</label>
                          </td>
                          <td>{reportData.itching}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Do you have frequent hiccups?</label>
                          </td>
                          <td>{reportData.hiccups}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Is there metallic taste in your mouth?</label>
                          </td>
                          <td>{reportData.metallic_taste}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Have you feel fatigue and weakness?</label>
                          </td>
                          <td>{reportData.fatigue}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Do you have difficulties of sleeping?</label>
                          </td>
                          <td>{reportData.Sleeping_difficulty}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>
                          Are there any changes in how much you urinate?
                          </label>
                          </td>
                          <td>{reportData.urinate_change}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>
                          Have you feel decreased mental sharpness?
                          </label>
                          </td>
                          <td>{reportData.mental_sharpness}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Do you have frequent muscle cramps / muscle twitches?</label>
                          </td>
                          <td>{reportData.muscle_twitches}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>
                          Are there Swelling of feet and ankles?
                          </label>
                          </td>
                          <td>{reportData.swelling}</td>
                          </tr>
                          <tr>
                          <td>
                          <label>Is there any difficulty in controlling high blood pressure?</label>
                          </td>
                          <td>{reportData.hypertension}</td>
                          </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                 
                  </div>
                </div>
                {/* <!-- /Invoice Item --> */}

                {/* <!-- Invoice Information --> */}
                {/* <div class="other-info">
                  <h4>Attach Medical Reports</h4>
                  <div class="form-group row">
                    <label class="col-form-label col-md-2">File Input</label>
                    <div class="col-md-10">
                      <input class="form-control" type="file" />
                    </div>
                  </div>
                </div> */}
                {/* <!-- /Invoice Information --> */}
                {/* <div class="col-6 col-sm-4 col-md-2 col-xl mb-3 mb-xl-0 text-right">
                  <Link to="/reportview"><button type="submit" class="btn btn-outline-success active"><i class="fas fa-plane" > </i>
                    Send
                  </button></Link>
                </div> */}

              </div>

            </div>

          </div>

        </div>


      </div>
    </>


  )
}
