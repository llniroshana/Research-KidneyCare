import React, { useEffect, useState } from 'react';
import Auth from "../../authentication/Auth";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
  Link,
} from "react-router-dom";

export default function ReportViewFour(params) {
  const { reportData } = params;
  const [formData, setformData] = useState(null);

  const criticalTrasplant = (criti) => {
    if (criti === "Yes") {
      return "The health condition is more likely to be at risk.";
    } else {
      return "The health condition is more likely to be normal";
    }
  }

  useEffect(() => {
    console.log(reportData);
    
    setformData(reportData);
    if(reportData!=null){
      addResults(reportData);
    }
    
  }, [reportData])
  
  const addResults = async (reportData) => {
    console.log({reportData})
    try {
      const requestOptions = {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: Auth.getUserId(),
          data: reportData,
        }),
      };
      const res1 = await fetch(
        `${process.env.REACT_APP_HOSTING_URL}/users/add-ckdtransplant`,
        requestOptions
      )
        .then((res) => res.json())
        .then((res) => {
          console.log(res);
        });
    } catch (e) {
        console.log(e);
    }
};
  return (
    <>
      {/* <!-- Breadcrumb --> */}
      <div class="breadcrumb-bar">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-md-12 col-12">
              <nav aria-label="breadcrumb" class="page-breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                    <a href="/home">Home</a>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">
                    Blank Page
                  </li>
                </ol>
              </nav>
              <h2 class="breadcrumb-title">Blank Page</h2>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- /Breadcrumb -->    */}

      <div class="content">
        <>
          {/* <!-- Breadcrumb --> */}
          <div class="breadcrumb-bar">
            <div class="container-fluid">
              <div class="row align-items-center">
                <div class="col-md-12 col-12">
                  <nav aria-label="breadcrumb" class="page-breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item">
                        <a href="/home">Home</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Transplant Patient
                      </li>
                    </ol>
                  </nav>
                  <h2 class="breadcrumb-title">Patient Prediction Report</h2>
                </div>
              </div>
            </div>
          </div>
          {/* <!-- /Breadcrumb -->    */}
        </>

        <div class="container-fluid">

          <div class="row">
            <div class="col-lg-8 offset-lg-2">
              <div class="invoice-content">
                 {/* <!--  Item --> */}
                {/* <div class="invoice-item">
                  <div class="row">
                    <div class="col-md-12">
                    <div class="col-md-12">
                      <div class="">
                        <table class="invoice-table-two table">
                          <tbody>
                            {formData && (
                              <div class="alert alert-danger">
                                <h4>
                                 Your Predicted Result - {criticalTrasplant(formData.result.critical)}{" "}
                                </h4>
                              </div>
                            )}
                          </tbody>

                        </table>
                      </div>
                    </div>
                    </div>
                  </div>
                </div> */}
                <div class="invoice-item">
                  <div class="row">
                    <div class="">
                      <p>
                        <strong style={{fontSize: 18, textAlign :"center"}} >Patient Prediction Report : </strong>
                      </p><br/>
                      <p>
                        <div class="col-md-12 col-xl-12 ">
                          <div class="">
                            <table class="invoice-table-two table">
                               <tbody>
                                {formData && (
                                  
                            
                                    <h4>
                                     
                                      {formData.result.critical === 'Yes' ? 
                                      <span className="alert alert-danger">The health condition is more likely to be at RISK. Please  get medical attention</span> : 
                                      <span className="alert alert-success">The health condition is more likely to be at NORMAL</span>}
                                                                            
                                    </h4>
                               

                                 )}
                              </tbody>
                            </table>
                          </div>
                       </div>
                      </p>
                    </div>
                 </div>
                </div>
                {/* <!--  Item --> */}

                {/* <!-- Item --> */}
                <div class="invoice-item invoice-table-wrap">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="table-responsive">
                        <table class="invoice-table table table-bordered text-center">
                          <thead>
                            <tr>
                              <th>Description</th>

                              <th>Symptoms Analysis Result</th>

                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>
                                <label>Gender</label>
                              </td>
                              <td>{reportData.Gender}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Time Duration</label>
                              </td>
                              <td>{reportData.TimeDu}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Flu</label>
                              </td>
                              <td>{reportData.Flu}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Chills</label>
                              </td>
                              <td>{reportData.chills}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Body Aches</label>
                              </td>
                              <td>{reportData.Body_aches}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>dizziness</label>
                              </td>
                              <td>{reportData.dizziness}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Headache</label>
                              </td>
                              <td>{reportData.headache}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Itching</label>
                              </td>
                              <td>{reportData.itching}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Fever</label>
                              </td>
                              <td>{reportData.fever}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Urine Less</label>
                              </td>
                              <td>{reportData.urinating_less}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Blood in urine</label>
                              </td>
                              <td>{reportData.blood_in_urine}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Urine Color Change</label>
                              </td>
                              <td>{reportData.urine_color_change}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>
                                  Blood Pressure
                                </label>
                              </td>
                              <td>{reportData.blood_pressure}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>
                                  Blood Sugar
                                </label>
                              </td>
                              <td>{reportData.blood_sugar}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Weight Gain</label>
                              </td>
                              <td>{reportData.weight_gain}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>
                                  Ankle Swelling
                                </label>
                              </td>
                              <td>{reportData.ankle_swelling}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Pain</label>
                              </td>
                              <td>{reportData.Pain}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Tired</label>
                              </td>
                              <td>{reportData.tired}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Sleeping Difficulties</label>
                              </td>
                              <td>{reportData.difficulties_sleeping}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Fatigue</label>
                              </td>
                              <td>{reportData.fatigue}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Eye Color</label>
                              </td>
                              <td>{reportData.eye_color}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Loss Appetite</label>
                              </td>
                              <td>{reportData.loss_of_appetite}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Difficulty Breath</label>
                              </td>
                              <td>{reportData.difficulty_breathing}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                {/* <!--  Item --> */}

              </div>

            </div>

          </div>

        </div>


      </div>
    </>


  )
}
