import React, { useEffect, useState } from 'react';
import Auth from '../../authentication/Auth';
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
  Link,
} from 'react-router-dom';

export default function ReportViewDiabetes(params) {
  const { reportData } = params;
  const [formData, setformData] = useState(null);

  const toCriticalDiabetic = (criti) => {
    if (criti == 'Dpresent') {
      return 'Critical';
    } else {
      return 'Not Critical';
    }
  };

  useEffect(() => {
    console.log(reportData);

    setformData(reportData);
    if (reportData != null) {
      addResults(reportData);
    }
  }, [reportData]);

  const addResults = async (reportData) => {
    console.log({ reportData });
    try {
      const requestOptions = {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: Auth.getUserId(),
          data: reportData,
        }),
      };
      const res1 = await fetch(
        `${process.env.REACT_APP_HOSTING_URL}/users/add-ckddiabetes`,
        requestOptions
      )
        .then((res) => res.json())
        .then((res) => {
          console.log(res);
        });
    } catch (e) {
      console.log(e);
    }
  };
  return (
    <>
      {/* <!-- Breadcrumb --> */}
      <div class="breadcrumb-bar">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-md-12 col-12">
              <nav aria-label="breadcrumb" class="page-breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                    <a href="/home">Home</a>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">
                    Blank Page
                  </li>
                </ol>
              </nav>
              <h2 class="breadcrumb-title">Blank Page</h2>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- /Breadcrumb -->    */}

      <div class="content">
        <>
          {/* <!-- Breadcrumb --> */}
          <div class="breadcrumb-bar">
            <div class="container-fluid">
              <div class="row align-items-center">
                <div class="col-md-12 col-12">
                  <nav aria-label="breadcrumb" class="page-breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item">
                        <a href="/home">Home</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                      Diabetes Mellitus
                      </li>
                    </ol>
                  </nav>
                  <h2 class="breadcrumb-title">Patient Prediction Report</h2>
                </div>
              </div>
            </div>
          </div>
          {/* <!-- /Breadcrumb -->    */}
        </>

        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-8 offset-lg-2">
              <div class="invoice-content">
               {/* <!-- Invoice Item --> */}
                {/* <div class="invoice-item">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="invoice-info">
                        <p class="invoice-details">
                          <strong>Report No:</strong> #00124 <br></br>
                          <strong>Issued Date:</strong> 15/10/2021<br></br>
                          <strong>Issued Time:</strong><br></br>
                          <strong>Result: </strong>{' '}
                          {reportData.result.Probability_of_having_Diabetes ===
                          'Dabsent'
                            ? 'Not Critical'
                            : 'Critical'}
                        </p>
                      </div>

                    </div>
                  </div>
                </div> */}
                <div class="invoice-item">
                  <div class="row">
                    <div class="">
                      <p>
                        <strong style={{fontSize: 18, textAlign :"center"}} >Patient Prediction Report : </strong>
                      </p><br/>
                      <p>
                        <div class="col-md-12 col-xl-12 ">
                          <div class="">
                            <table class="invoice-table-two table">
                               <tbody>
                                {reportData && (
                                  
                                  
                                    <h4>
                                      
                                      {reportData.result.Probability_of_having_Diabetes === 'Dabsent' ? 
                                       <h5><span className="alert alert-success">The health condition is more likely to be at NORMAL.Please contact your doctor, stay Safe.</span></h5> : 
                                      <h5><span className="alert alert-danger">The health condition is more likely to be at Risk.Please immediately get Nephrology unit medical attention </span></h5>}
                                                                            
                                    </h4>
                               

                                 )}
                              </tbody>
                            </table>
                          </div>
                       </div>
                      </p>
                    </div>
                 </div>
                </div>
                {/* <!-- /Invoice Item --> */}

                {/* <!-- Invoice Item --> */}
                <div class="invoice-item invoice-table-wrap">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="table-responsive">
                        <table class="invoice-table table table-bordered text-center">
                          <thead>
                            <tr>
                              <th>Description</th>

                              <th>Symptoms Analysis Result</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>
                                <label>Age Group</label>
                              </td>
                              <td>{reportData.ageGroup}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Diabetes Type</label>
                              </td>
                              <td>Type {reportData.dtype}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Gender</label>
                              </td>
                              <td>{reportData.gender}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>BMI</label>
                              </td>
                              <td>{reportData.bmi}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Diabetes Duration (years)</label>
                              </td>
                              <td>{reportData.duration}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Urine Level</label>
                              </td>
                              <td>{reportData.urinelevel}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Fast Blood Sugar Level</label>
                              </td>
                              <td>{reportData.fastbloodsugar}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>AIC report status</label>
                              </td>
                              <td>{reportData.aic}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Diastolic Blood Pressure</label>
                              </td>
                              <td>{reportData.dbloodpressure}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Systolic Blood Pressure</label>
                              </td>
                              <td>{reportData.sbloodpressure}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Blood Sugar Level</label>
                              </td>
                              <td>{reportData.bloodSugarLevel}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Do you have Hypertension?</label>
                              </td>
                              <td>{reportData.hypertension}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>
                                  Do you or your family members have history in
                                  developing CKD?
                                </label>
                              </td>
                              <td>{reportData.history1}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>
                                  Do you have any other kidney problems?
                                </label>
                              </td>
                              <td>{reportData.ckd}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Do you have smoking habits?</label>
                              </td>
                              <td>{reportData.smoking}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>
                                  Any albumin content in urin sample reports
                                </label>
                              </td>
                              <td>{reportData.albumin}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Do you feel any thirsty regulary?</label>
                              </td>
                              <td>{reportData.thirsty}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Do you have high blood pressure</label>
                              </td>
                              <td>{reportData.highbloodpressure}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Short Breath</label>
                              </td>
                              <td>{reportData.shortbreath}</td>
                            </tr>
                            <tr>
                              <td>
                                <label>Loss Appatite</label>
                              </td>
                              <td>{reportData.appatite}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="col-md-6 col-xl-4 ml-auto">
                      <div class="table-responsive">
                        <table class="invoice-table-two table">
                          <tbody>
                            {/* {formData && (
                              <div class="alert alert-danger alert-dismissible">
                                <h6>
                                  <i class="icon fa fa-check"></i> Your
                                  Predicted critical -{' '}
                                  {toCriticalDiabetic(
                                    formData.result
                                      .Probability_of_having_Diabetes
                                  )}{' '}
                                </h6>
                              </div>
                            )} */}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                {/* <!-- /Invoice Item --> */}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
