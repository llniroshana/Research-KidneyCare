import React, { useEffect, useState } from "react";

import {
  withGoogleMap,
  withScriptjs,
  GoogleMap,
  Marker,
  InfoWindow,
} from "react-google-maps";
import * as hospitalData from "../data/hospitals-locations.json";

export default function Hospital(params) {
  function Map() {
    const [selectedHospital, setSelectedHospitals] = useState(null);

    useEffect(() => {
      const listener = (e) => {
        if (e.key === "Escape") {
          setSelectedHospitals(null);
        }
      };
      window.addEventListener("keydown", listener);

      return () => {
        window.removeEventListener("keydown", listener);
      };
    }, []);

    return (
      <GoogleMap
        defaultZoom={7}
        defaultCenter={{ lat: 8.4, lng: 80.771797 }}
        // defaultOptions={{ styles: mapStyles }}
      >
        {hospitalData.features.map((hospital) => (
          <Marker
            key={hospital.properties.NAME}
            position={{
              lat: hospital.geometry.coordinates[1],
              lng: hospital.geometry.coordinates[0],
            }}
            onClick={() => {
              setSelectedHospitals(hospital);
            }}
            // icon={{
            //   url: `/assets/img/images.jfif`,
            //   scaledSize: new window.google.maps.Size(25, 25)
            // }}
          />
        ))}

        {selectedHospital && (
          <InfoWindow
            onCloseClick={() => {
              setSelectedHospitals(null);
            }}
            position={{
              lat: selectedHospital.geometry.coordinates[1],
              lng: selectedHospital.geometry.coordinates[0],
            }}
          >
            <div>
              <h6>{selectedHospital.properties.NAME}</h6>
              <p>{selectedHospital.properties.ADDRESS}</p>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
    );
  }
  const MapWrapped = withScriptjs(withGoogleMap(Map));
  return (
    <>
      {/* <!-- Breadcrumb --> */}
      <div class="breadcrumb-bar">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-md-12 col-12">
              <nav aria-label="breadcrumb" class="page-breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                    <a href="/home">Home</a>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">
                    Blank Page
                  </li>
                </ol>
              </nav>
              <h2 class="breadcrumb-title">Blank Page</h2>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- /Breadcrumb -->    */}

      <div class="content">
        <>
          {/* <!-- Breadcrumb --> */}
          <div class="breadcrumb-bar">
            <div class="container-fluid">
              <div class="row align-items-center">
                <div class="col-md-12 col-12">
                  <nav aria-label="breadcrumb" class="page-breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item">
                        <a href="/home">Home</a>
                      </li>
                      <li
                        class="breadcrumb-item active"
                        aria-current="page"
                      ></li>
                    </ol>
                  </nav>
                  <h2 class="breadcrumb-title">Islandwide Nephrology Units</h2>
                </div>
              </div>
            </div>
          </div>
          {/* <!-- /Breadcrumb -->    */}
        </>

        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-6 col-lg-12 order-md-last order-sm-last order-last map-left">
              <div class="row">
                <div class="col-sm-6 col-md-4 col-xl-6">
                  <div class="profile-widget">
                    <div class="doc-img">
                      <a href="doctor-profile.html">
                        <img
                          class="img-fluid"
                          alt="User Image"
                          src="assets/img/n2.jfif"
                        />
                      </a>
                      <a href="javascript:void(0)" class="fav-btn">
                        <i class="far fa-bookmark"></i>
                      </a>
                    </div>
                    <div class="pro-content">
                      <h3 class="title">
                        <a href="doctor-profile.html">
                          Transplant Unit of National Hospital of Sri Lanka
                        </a>
                        <i class="fas fa-check-circle verified"></i>
                      </h3>
                      <p class="speciality">Hospital</p>
                      <div class="rating">
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <span class="d-inline-block average-rating">(17)</span>
                      </div>
                      <ul class="available-info">
                        <li>
                          <i class="fas fa-map-marker-alt"></i> Colombo, Sri Lanka
                        </li>
                        <li>
                          <i class="far fa-clock"></i> Available on 24/7
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 col-md-4 col-xl-6">
                  <div class="profile-widget">
                    <div class="doc-img">
                      <a href="doctor-profile.html">
                        <img
                          class="img-fluid"
                          alt="User Image"
                          src="assets/img/n3.jpg"
                        />
                      </a>
                      <a href="javascript:void(0)" class="fav-btn">
                        <i class="far fa-bookmark"></i>
                      </a>
                    </div>
                    <div class="pro-content">
                      <h3 class="title">
                        <a href="">
                          The National Institute of Nephrology Dialysis
                          Transplantation
                        </a>
                        <i class="fas fa-check-circle verified"></i>
                      </h3>
                      <p class="speciality">Government hospital</p>
                      <div class="rating">
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <span class="d-inline-block average-rating">(17)</span>
                      </div>
                      <ul class="available-info">
                        <li>
                          <i class="fas fa-map-marker-alt"></i> Anuradhapura
                        </li>
                        <li>
                          <i class="far fa-clock"></i> Available on 24/7
                          </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 col-md-4 col-xl-6">
                  <div class="profile-widget">
                    <div class="doc-img">
                      <a href="doctor-profile.html">
                        <img
                          class="img-fluid"
                          alt="User Image"
                          src="assets/img/n4.jfif"
                        />
                      </a>
                      <a href="javascript:void(0)" class="fav-btn">
                        <i class="far fa-bookmark"></i>
                      </a>
                    </div>
                    <div class="pro-content">
                      <h3 class="title">
                        <a href="doctor-profile.html">
                          Kidney Transplant and Renal Care Unit
                        </a>
                        <i class="fas fa-check-circle verified"></i>
                      </h3>
                      <p class="speciality">Hospital</p>
                      <div class="rating">
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <span class="d-inline-block average-rating">(17)</span>
                      </div>
                      <ul class="available-info">
                        <li>
                          <i class="fas fa-map-marker-alt"></i> Cancer Unit,
                          Kandy
                        </li>
                        <li>
                          <i class="far fa-clock"></i> Open 24 hours
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 col-md-4 col-xl-6">
                  <div class="profile-widget">
                    <div class="doc-img">
                      <a href="doctor-profile.html">
                        <img
                          class="img-fluid"
                          alt="User Image"
                          src="assets/img/n7.jpg"
                        />
                      </a>
                      <a href="javascript:void(0)" class="fav-btn">
                        <i class="far fa-bookmark"></i>
                      </a>
                    </div>
                    <div class="pro-content">
                      <h3 class="title">
                        <a href="doctor-profile.html">Nephrology Unit</a>
                        <i class="fas fa-check-circle verified"></i>
                      </h3>
                      <p class="speciality">Hospital</p>
                      <div class="rating">
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <span class="d-inline-block average-rating">(17)</span>
                      </div>
                      <ul class="available-info">
                        <li>
                          <i class="fas fa-map-marker-alt"></i> Badulla, sri Lanka
                        </li>
                        <li>
                          <i class="far fa-clock"></i> Available on 24/7
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 col-md-4 col-xl-6">
                  <div class="profile-widget">
                    <div class="doc-img">
                      <a href="doctor-profile.html">
                        <img
                          class="img-fluid"
                          alt="User Image"
                          src="assets/img/n1.jpg"
                        />
                      </a>
                      <a href="javascript:void(0)" class="fav-btn">
                        <i class="far fa-bookmark"></i>
                      </a>
                    </div>
                    <div class="pro-content">
                      <h3 class="title">
                        <a href="doctor-profile.html">Habarana Hospital</a>
                        <i class="fas fa-check-circle verified"></i>
                      </h3>
                      <p class="speciality">
                        Habarana Hospital
                      </p>
                      <div class="rating">
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <i class="fas fa-star filled"></i>
                        <span class="d-inline-block average-rating">(17)</span>
                      </div>
                      <ul class="available-info">
                        <li>
                          <i class="fas fa-map-marker-alt"></i> Habarana, Polonaruwa
                        </li>
                        <li>
                          <i class="far fa-clock"></i> Available on 24/7
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* <!-- /content-left--> */}
            <div class="col-md-6 " style={{position:"sticky",marginTop: 20,}}>
              {/* <div
                className="col-md-6"
                style={{ marginTop: 80, marginLeft: 10, marginBottom: 100 }}
              ></div> */}
             
                <MapWrapped
                  googleMapURL={`https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=geometry,drawing,places&key=${process.env.REACT_APP_GOOGLE_KEY}`}
                  loadingElement={<div style={{ height: `80%` }} />}
                  containerElement={<div style={{ height: `80%` }} />}
                  mapElement={<div style={{ height: `80%` }} />}
                />
            
              {/* <!-- map--> */}
            </div>
            {/* <!-- /map-right--> */}
          </div>
          {/* <!-- /row--> */}
        </div>
      </div>
    </>
  );
}
