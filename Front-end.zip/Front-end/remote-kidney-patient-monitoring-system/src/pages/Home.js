import React from 'react'

export default function Home() {
  return (
    <>
      {/* <!-- Home Banner --> */}
      <section class="section section-search" style={{ marginTop: "85px" }}>
        <div class="container-fluid">
          <div class="banner-wrapper">
            <div class="banner-header text-center">
              <h1>Kidney Care, Act Now Protect your Kidney</h1>
              <p>We are here to care for your kidney.</p>
            </div>

          </div>
        </div>
      </section>
      {/* <!-- /Home Banner -->  */}

      <br></br>

      {/* <!-- Breadcrumb --> */}
      <div class="breadcrumb-bar">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-md-12 col-12">

              <h6 class="breadcrumb-title text-center">Our Specialities</h6>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Breadcrumb --> */}

      {/* <!-- Clinic and Specialities --> */}

      <section class="section section-specialities">
        <div class="container-fluid">
          <p class="sub-title text-center">

          </p>
          <div class="row justify-content-center">
            <div class=" col-sm-12 col-md-6 ">
              {/* <!-- Slider --> */}
              <div class="row d-flex justify-content-between">
                {/* <!-- Slider Item --> */}
                <a href="/page1">
                  <div class="speicality-item text-center">
                    <div class="speicality-img">

                      <img src={`${process.env.PUBLIC_URL}/assets/img/U.jpg`} class="img-fluid" alt="Logo" />
                      <span
                      ><i class="fa fa-circle" aria-hidden="true"></i>
                      </span>
                    </div>
                    <p>CKD Risk Analysis</p>
                  </div></a>
                {/* <!-- /Slider Item --> */}
                <a href="/page2">
                  <div class="speicality-item text-center">
                    <div class="speicality-img">

                      <img
                        src="assets/img/U3.jpg"
                        class="img-fluid"
                        alt="Speciality"
                      />
                      <span
                      ><i class="fa fa-circle" aria-hidden="true"></i>
                      </span>
                    </div>
                    <p>Diabetes Mellitus</p>
                  </div></a>
                {/* <!-- /Slider Item --> */}
                <a href="/page3">
                  <div class="speicality-item text-center">
                    <div class="speicality-img">

                      <img
                        src="assets/img/U2.jpg"
                        class="img-fluid"
                        alt="Speciality"
                      />
                      <span
                      ><i class="fa fa-circle" aria-hidden="true"></i>
                      </span>
                    </div>
                    <p>Elderly Patient</p>
                  </div></a>
                {/* <!-- /Slider Item --> */}
                <a href="/page4">
                  <div class="speicality-item text-center">
                    <div class="speicality-img">

                      <img
                        src="assets/img/U4.jpg"
                        class="img-fluid"
                        alt="Speciality"
                      />
                      <span
                      ><i class="fa fa-circle" aria-hidden="true"></i>
                      </span>
                    </div>
                    <p>Transpalnt Patient</p>
                  </div></a>
              </div>

              {/* <!-- /Slider Item --> */}

              {/* <!-- /Slider --> */}
            </div>
          </div>
        </div>
      </section>

      {/* <!-- Breadcrumb --> */}
      <div class="breadcrumb-bar">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-md-12 col-12">

              <h6 class="breadcrumb-title text-center">Blogs and News</h6>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Breadcrumb --> */}

      {/* <!-- Blog Section --> */}
      <section class="section section-blogs">
        <div class="container-fluid">
          {/* <!-- Section Header --> */}
          <div class="text-center">

            <p class="sub-title">
            Chronic Kidney disease(CKD) is a serious illness involving the gradual loss of kidney function. Kidneys provide the vital function of filtering waste from the body. When your kidneys don’t work properly, this can trigger a range of symptoms
            </p>
          </div>
          {/* <!-- Section Header --> */}

          <div class="row blog-grid-row">
            <div class="col-md-6 col-lg-3 col-sm-12">
              {/* <!-- Blog Post --> */}
              <div class="blog grid-blog">
                <div class="blog-image">
                  <a href="blog-details.html"
                  ><img
                      class="img-fluid"
                      src="assets/img/ks4.jpg"
                      alt="Post Image"
                    /></a>
                </div>
                <div class="blog-content">
          
                  <h3 class="blog-title">
                    <a href="https://www.niddk.nih.gov/health-information/kidney-disease/kidneys-how-they-work"
                    >How Your Kidneys Work</a
                    >
                  </h3>
                  <p class="mb-0">
                  Most people know that a major function of the kidneys is to remove waste products and excess fluid from the body. These waste products and excess fluid are removed through the urine. The production of urine involves highly complex steps of excretion and re-absorption.
                  </p>
                </div>
              </div>
              {/* <!-- Blog Post --> */}
            </div>
            <div class="col-md-6 col-lg-3 col-sm-12">
              {/* <!-- Blog Post --> */}
              <div class="blog grid-blog">
                <div class="blog-image">
                  <a href="blog-details.html"
                  ><img
                      class="img-fluid"
                      src="assets/img/ks3.jpg"
                      alt="Post Image"
                    /></a>
                </div>
                <div class="blog-content">

                  <h3 class="blog-title">
                    <a href="https://www.healthline.com/health/kidney-health"
                    >Health care that makes you smile</a
                    >
                  </h3>
                  <p class="mb-0">
                  This blog features a collection of articles and stories by writers who understand firsthand the effects of kidney disease. Whether they live with the disease or have a loved one who does, these writers open their hearts and offer encouragement to those battling the disease. For example, read about Michelle’s experiences supporting her boyfriend through kidney failure. 
                  </p>
                </div>
              </div>
              {/* <!-- Blog Post --> */}
            </div>
            <div class="col-md-6 col-lg-3 col-sm-12">
              {/* <!-- Blog Post --> */}
              <div class="blog grid-blog">
                <div class="blog-image">
                  <a href="blog-details.html"
                  ><img
                      class="img-fluid"
                      src="assets/img/ks5.jpg"
                      alt="Post Image"
                    /></a>
                </div>
                <div class="blog-content">
                  <h3 class="blog-title">
                    <a href="https://www.kidneyfund.org/kidney-disease/chronic-kidney-disease-ckd/kidney-friendly-diet-for-ckd.html"
                    >Nutrition for kidney patients</a
                    >
                  </h3>
                  <p class="mb-0">
                  Diet is an important part of living well with kidney disease. As your kidney disease progresses your dietary needs will likely change as well. Most patients in the early stages of kidney disease need to limit the amount of sodium in their diet. Some patients may be told to limit protein in their diet as well. Be sure to talk with your healthcare provider about your individual nutrition needs.
                  </p>
                </div>
              </div>
              {/* <!-- Blog Post --> */}
            </div>
            <div class="col-md-6 col-lg-3 col-sm-12">
              {/* <!-- Blog Post --> */}
              <div class="blog grid-blog">
                <div class="blog-image">
                  <a href="blog-details.html"
                  ><img
                      class="img-fluid"
                      src="assets/img/ks2.jpg"
                      alt="Post Image"
                    /></a>
                </div>
                <div class="blog-content">
                  <h3 class="blog-title">
                    <a href="https://www.niddk.nih.gov/health-information/kidney-disease"
                    >About Kidney Disease</a
                    >
                  </h3>
                  <p class="mb-0">
                  Kidney disease is a serious illness involving the gradual loss of kidney function. Kidneys provide the vital function of filtering waste from the body. When your kidneys don’t work properly, this can trigger a range of symptoms
                  </p>
                </div>
              </div>
              {/* <!-- Blog Post --> */}
            </div>
          </div>
        </div>
      </section>
      {/* <!-- Blog Section --> */}
    </>
  )
}
