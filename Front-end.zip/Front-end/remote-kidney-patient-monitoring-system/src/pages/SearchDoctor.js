import React from "react";

export default function SearchDoctor(){

    return(
        <>
                {/* <!-- Breadcrumb --> */}
                <div class="breadcrumb-bar">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-md-12 col-12">
                            <nav aria-label="breadcrumb" class="page-breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="/home">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Doctors
                                    </li>
                                </ol>
                            </nav>
                            <h2 class="breadcrumb-title">Doctors Work With Us</h2>
                        </div>
                    </div>
                </div>
            </div>
            {/* <!-- /Breadcrumb -->    */}
		
			
			{/* <!-- Page Content --> */}
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						<div class="col-md-12 col-lg-4 col-xl-3 theiaStickySidebar">
							
						</div>
						
						<div class="col-md-12 col-lg-8 col-xl-9">

							{/* <!-- Doctor Widget --> */}
							<div class="card">
								<div class="card-body">
									<div class="doctor-widget">
										<div class="doc-info-left">
											<div class="doctor-img">
												<a href="doctor-profile.html">
													<img src="assets/img/doctors/doctor.jpg" class="img-fluid" alt="User Image"/>
												</a>
											</div>
											<div class="doc-info-cont">
												<h4 class="doc-name"><a href="doctor-profile.html">Dr. Arjuna Marasinghe</a></h4>
												<p class="doc-speciality">MBBS - Sri Lanka</p> 
												<h5 class="doc-department"><img src="assets/img/specialities/specialities-01.png" class="img-fluid" alt="Speciality"/>Nephrologist</h5>
												<div class="rating">
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star"></i>
													<span class="d-inline-block average-rating">(15)</span>
												</div>
												<div class="clinic-details">
													<p class="doc-location"><i class="fas fa-map-marker-alt"></i> Colombo, Sri Lanka</p>
													
												</div>
												<div class="clinic-services">
													<span>Dialysis</span>
													<span>Transplant</span>
												</div>
											</div>
										</div>
										<div class="doc-info-right">
											<div class="clini-infos">
												<ul>
													<li><i class="far fa-thumbs-up"></i> 98%</li>
													<li><i class="far fa-comment"></i> 15 Feedback</li>
													<li><i class="fas fa-map-marker-alt"></i> Colombo - Sri Lanka</li>
													<li><i class="far fa-money-bill-alt"></i> 1000LKR - 2000LKR<i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i> </li>
												</ul>
											</div>
											<div class="clinic-booking">
												<a class="view-pro-btn" href="mailto:demo@demo.com">Contact Doctor</a>
												
											</div>
										</div>
									</div>
								</div>
							</div>
							{/* <!-- /Doctor Widget --> */}

							{/* <!-- Doctor Widget --> */}
							<div class="card">
								<div class="card-body">
									<div class="doctor-widget">
										<div class="doc-info-left">
											<div class="doctor-img">
												<a href="doctor-profile.html">
													<img src="assets/img/doctors/doctor.jpg" class="img-fluid" alt="User Image"/>
												</a>
											</div>
											<div class="doc-info-cont">
												<h4 class="doc-name"><a href="doctor-profile.html">Dr. Chinthana Galahitiyawa</a></h4>
												<p class="doc-speciality">MBBS - Sri Lanka</p>
												<h5 class="doc-department"><img src="assets/img/specialities/specialities-01.png" class="img-fluid" alt="Speciality"/>Nephrologist</h5>
												<div class="rating">
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star"></i>
													<span class="d-inline-block average-rating">(17)</span>
												</div>
												<div class="clinic-details">
													<p class="doc-location"><i class="fas fa-map-marker-alt"></i> Colombo, Sri Lanka</p>
													
												</div>
												<div class="clinic-services">
													<span>Dialysis</span>
													<span>Transplant</span>
												</div>
											</div>
										</div>
										<div class="doc-info-right">
											<div class="clini-infos">
												<ul>
													<li><i class="far fa-thumbs-up"></i> 98%</li>
													<li><i class="far fa-comment"></i> 17 Feedback</li>
													<li><i class="fas fa-map-marker-alt"></i> Colombo, Sri Lanka</li>
													<li><i class="far fa-money-bill-alt"></i> 2000LKR - 3000LKR <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i> </li>
												</ul>
											</div>
											<div class="clinic-booking">
												<a class="view-pro-btn" href="mailto:demo@demo.com">Contact Doctor</a>
											
											</div>
										</div>
									</div>
								</div>
							</div>
							{/* <!-- /Doctor Widget --> */}

							{/* <!-- Doctor Widget --> */}
							<div class="card">
								<div class="card-body">
									<div class="doctor-widget">
										<div class="doc-info-left">
											<div class="doctor-img">
												<a href="doctor-profile.html">
													<img src="assets/img/doctors/doctor.jpg" class="img-fluid" alt="User Image"/>
												</a>
											</div>
											<div class="doc-info-cont">
												<h4 class="doc-name"><a href="doctor-profile.html">Dr. Ranga Weerakkody</a></h4>
												<p class="doc-speciality">MBBS - Sri Lanka</p>
												<h5 class="doc-department"><img src="assets/img/specialities/specialities-01.png" class="img-fluid" alt="Speciality"/>Nephrologist</h5>
												<div class="rating">
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star"></i>
													<span class="d-inline-block average-rating">(12)</span>
												</div>
												<div class="clinic-details">
													<p class="doc-location"><i class="fas fa-map-marker-alt"></i> Colombo - Sri Lanka</p>
													
												</div>
												<div class="clinic-services">
													<span>Dialysis</span>
													<span>Transplant</span>
												</div>
											</div>
										</div>
										<div class="doc-info-right">
											<div class="clini-infos">
												<ul>
													<li><i class="far fa-thumbs-up"></i> 98%</li>
													<li><i class="far fa-comment"></i> 12 Feedback</li>
													<li><i class="fas fa-map-marker-alt"></i> Colombo - Sri Lanka</li>
													<li><i class="far fa-money-bill-alt"></i> 1500LKR - 2500LKR <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i> </li>
												</ul>
											</div>
											<div class="clinic-booking">
												<a class="view-pro-btn" href="mailto:demo@demo.com">Contact Doctor</a>
										
											</div>
										</div>
									</div>
								</div>
							</div>
							{/* <!-- /Doctor Widget --> */}

							{/* <!-- Doctor Widget --> */}
							<div class="card">
								<div class="card-body">
									<div class="doctor-widget">
										<div class="doc-info-left">
											<div class="doctor-img">
												<a href="doctor-profile.html">
													<img src="assets/img/doctors/doctor.jpg" class="img-fluid" alt="User Image"/>
												</a>
											</div>
											<div class="doc-info-cont">
												<h4 class="doc-name"><a href="doctor-profile.html">Dr. Sanjaya Heiyanthuduwa</a></h4>
												<p class="doc-speciality">MBBS - Sri Lanka</p>
												<h5 class="doc-department"><img src="assets/img/specialities/specialities-01.png" class="img-fluid" alt="Speciality"/>Nephrologist</h5>
												<div class="rating">
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star"></i>
													<span class="d-inline-block average-rating">(17)</span>
												</div>
												<div class="clinic-details">
													<p class="doc-location"><i class="fas fa-map-marker-alt"></i> Colombo - Sri Lanka</p>
													
												</div>
												<div class="clinic-services">
													<span>Dialysis</span>
													<span>Transplant</span>
												</div>
											</div>
										</div>
										<div class="doc-info-right">
											<div class="clini-infos">
												<ul>
													<li><i class="far fa-thumbs-up"></i> 98%</li>
													<li><i class="far fa-comment"></i> 17 Feedback</li>
													<li><i class="fas fa-map-marker-alt"></i> Colombo - Sri Lanka</li>
													<li><i class="far fa-money-bill-alt"></i> 2000LKR - 3000LKR <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i> </li>
												</ul>
											</div>
											<div class="clinic-booking">
												<a class="view-pro-btn" href="mailto:demo@demo.com">Contact Doctor</a>
											
											</div>
										</div>
									</div>
								</div>
							</div>
							{/* <!-- /Doctor Widget --> */}

							{/* <!-- Doctor Widget --> */}
							<div class="card">
								<div class="card-body">
									<div class="doctor-widget">
										<div class="doc-info-left">
											<div class="doctor-img">
												<a href="doctor-profile.html">
													<img src="assets/img/doctors/doctor.jpg" class="img-fluid" alt="User Image"/>
												</a>
											</div>
											<div class="doc-info-cont">
												<h4 class="doc-name"><a href="doctor-profile.html">Dr. H. L. Hordagoda</a></h4>
												<p class="doc-speciality">MBBS - Sri Lanka</p>
												<h5 class="doc-department"><img src="assets/img/specialities/specialities-01.png" class="img-fluid" alt="Speciality"/>Nephrologist</h5>
												<div class="rating">
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star filled"></i>
													<i class="fas fa-star"></i>
													<span class="d-inline-block average-rating">(17)</span>
												</div>
												<div class="clinic-details">
													<p class="doc-location"><i class="fas fa-map-marker-alt"></i> Kandy - Sri Lanka</p>
													
												</div>
												<div class="clinic-services">
													<span>Dialysis</span>
													<span>Transplant</span>
												</div>
											</div>
										</div>
										<div class="doc-info-right">
											<div class="clini-infos">
												<ul>
													<li><i class="far fa-thumbs-up"></i> 98%</li>
													<li><i class="far fa-comment"></i> 17 Feedback</li>
													<li><i class="fas fa-map-marker-alt"></i> Kandy - Sri Lanka</li>
													<li><i class="far fa-money-bill-alt"></i> 1000LKR - 2000LKR <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i> </li>
												</ul>
											</div>
											<div class="clinic-booking">
												<a class="view-pro-btn" href="mailto:demo@demo.com">Contact Doctor</a>
												
											</div>
										</div>
									</div>
								</div>
							</div>
							{/* <!-- /Doctor Widget --> */}
						

							
						</div>
					</div>

				</div>

			</div>		
		
        </>
    )
}