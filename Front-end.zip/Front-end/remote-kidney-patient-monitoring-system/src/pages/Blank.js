import React from 'react'

export default function Blank() {
    return (
        <div>
               <p>This is the second page.</p>
        </div>
    )
}
