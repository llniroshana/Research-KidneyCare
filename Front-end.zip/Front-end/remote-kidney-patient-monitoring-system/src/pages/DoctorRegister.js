import React, { useEffect, useState } from "react";
import * as yup from "yup";
import { Formik } from "formik";
import { Container, Form, Col, Row, Button, Alert } from "react-bootstrap";
import {
    BrowserRouter as Router,
    Route,
    Switch,
    Redirect,
    Link,
} from "react-router-dom";

export default function DoctorRegister() {
    const [show, setShow] = useState(false);
    const [error, setError] = useState("");
    const [redirect, setRedirect] = useState(false);

    // validatin schema
    const schema = yup.object({
        name: yup.string().required("Name is required!"),
        email: yup
            .string()
            .email("Invalid Email : Ex example@example.com")
            .required("Email is required!"),
        phone: yup.string().required("Phone is required")
            .required()
            .matches(/^[0-9]+$/, "Must be only digits")
            .min(10, 'Must be exactly 10 digits')
            .max(10, 'Must be exactly 10 digits'),
        password: yup.string().required("Password is required").min(5, 'Must be longer than 5 characters'),
        changepassword: yup.string().when("password", {
            is: (val) => (val && val.length > 0 ? true : false),
            then: yup
                .string()
                .oneOf([yup.ref("password")], "Both password need to be the same"),
        }),
    });

    useEffect(() => {
        console.log();
    }, []);

    const registerDoctor = async (event) => {
        // event.preventDefault();
        console.log(event);
        try {
            const requestOptions = {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    uType: "Doctor",
                    name: event.name,
                    phone: event.phone,
                    email: event.email.toLowerCase(),
                    password: event.password,
                }),
            };
            const res = await fetch(
                `${process.env.REACT_APP_HOSTING_URL}/users/register`,
                requestOptions
            );

            const data = await res.json();

            console.log(data);
            if (data.hasOwnProperty("error")) {
                setError(data.error);
                setShow(true);
            } else {
                setError("");
                setShow(true);
            }
        } catch (e) {
            console.log(e);
        }
    };
    if (redirect) {
        return <Redirect to="/login" />;
    }
    return (
        <>
            {/* <!-- Breadcrumb --> */}
            <div class="breadcrumb-bar">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-md-12 col-12">
                            <nav aria-label="breadcrumb" class="page-breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="/home">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Blank Page
                                    </li>
                                </ol>
                            </nav>
                            <h2 class="breadcrumb-title">Blank Page</h2>
                        </div>
                    </div>
                </div>
            </div>
            {/* <!-- /Breadcrumb -->    */}

            <div class="content">
                <>
                    {/* <!-- Breadcrumb --> */}
                    <div class="breadcrumb-bar">
                        <div class="container-fluid">
                            <div class="row align-items-center">
                                <div class="col-md-12 col-12">
                                    <nav aria-label="breadcrumb" class="page-breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="/home">Home</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">
                                          
                                            </li>
                                        </ol>
                                    </nav>
                                    <h2 class="breadcrumb-title">Doctor Register</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* <!-- /Breadcrumb -->    */}
                </>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8 offset-md-2">
                            {/* <!-- Account Content --> */}
                            <div class="account-content">
                                <div class="row align-items-center justify-content-center">
                                    <div class="col-md-7 col-lg-6 login-left">
                                        <img
                                            src="assets/img/login-banner.png"
                                            class="img-fluid"
                                            alt="Login Banner"
                                        />
                                    </div>
                                    <div class="col-md-12 col-lg-6 login-right">
                                        <div class="login-header">
                                            <h3>
                                            Doctor Register <a href="/register">Not a Doctor?</a>
                                            </h3>
                                        </div>
                                        <Alert
                                            show={show}
                                            variant={error == "" ? "success" : "danger"}
                                        >
                                            <Alert.Heading>
                                                {error != "" ? (
                                                    error
                                                ) : (
                                                    <>
                                                        Member Registered Successfully !
                                                        <p className="text-secondary">
                                                            Please Login to continue
                                                        </p>
                                                    </>
                                                )}
                                            </Alert.Heading>

                                            <hr />
                                            <div className="d-flex justify-content-end">
                                                {error == "" ? (
                                                    <Button
                                                        onClick={() => setRedirect(true)}
                                                        variant="info"
                                                        className="btnPrimary"
                                                    >
                                                        Done
                                                    </Button>
                                                ) : (
                                                    <Button
                                                        onClick={() => setShow(false)}
                                                        variant="primary"
                                                        className="btnPrimary"
                                                    >
                                                        OK
                                                    </Button>
                                                )}
                                            </div>
                                        </Alert>
                                        {/* <!-- Register Form --> */}
                                        <Formik
                                            validationSchema={schema}
                                            onSubmit={registerDoctor}
                                            initialValues={{
                                                name: "",
                                                email: "",
                                            }}
                                        >
                                            {({
                                                handleSubmit,
                                                handleChange,
                                                handleBlur,
                                                values,
                                                touched,
                                                isValid,
                                                errors,
                                            }) => (
                                                <form onSubmit={handleSubmit}>
                                                    <div class="form-group form-focus">
                                                        <input type="text" class="form-control floating" name="name"
                                                            onBlur={handleBlur}
                                                            onChange={handleChange}
                                                        />
                                                        <label class="focus-label">Name</label>
                                                        <span className="error" style={{ color: "red" }}>
                                                            {errors.name}
                                                        </span>
                                                    </div>
                                                    <div class="form-group form-focus">
                                                        <input type="text" class="form-control floating" name="email"
                                                            onBlur={handleBlur}
                                                            onChange={handleChange}
                                                        />
                                                        <label class="focus-label">Email</label>
                                                        <span className="error" style={{ color: "red" }}>
                                                            {errors.email}
                                                        </span>
                                                    </div>
                                                    <div class="form-group form-focus">
                                                        <input type="text" class="form-control floating" name="phone"
                                                            onBlur={handleBlur}
                                                            onChange={handleChange}
                                                        />
                                                        <label class="focus-label">Mobile Number</label>
                                                        <span className="error" style={{ color: "red" }}>
                                                            {errors.phone}
                                                        </span>
                                                    </div>
                                                    <div class="form-group form-focus">
                                                        <input
                                                            name="password"
                                                            type="password"
                                                            onBlur={handleBlur}
                                                            onChange={handleChange}
                                                            class="form-control floating"
                                                        />
                                                        <label class="focus-label">Create Password</label>
                                                        <span className="error" style={{ color: "red" }}>
                                                            {errors.password}
                                                        </span>
                                                    </div>
                                                    <div class="form-group form-focus">
                                                        <input
                                                            name="changepassword"
                                                            type="password"
                                                            onBlur={handleBlur}
                                                            onChange={handleChange}
                                                            class="form-control floating"
                                                        />
                                                        <label class="focus-label">Confirm Password</label>
                                                        <span className="error" style={{ color: "red" }}>
                                                            {errors.changepassword}
                                                        </span>
                                                    </div>
                                                    <div class="text-right">
                                                        <a class="forgot-link" href="/login">
                                                            Already have an account?
                                                        </a>
                                                    </div>
                                                    <button
                                                        class="btn btn-primary btn-block btn-lg login-btn"
                                                        type="submit"
                                                    >
                                                        Signup
                                                    </button>
                                                    <div class="login-or">
                                                        <span class="or-line"></span>
                                                        <span class="span-or">or</span>
                                                    </div>
                                                    <div class="row form-row social-login">
                                                        <div class="col-6">
                                                            <a href="#" class="btn btn-facebook btn-block">
                                                                <i class="fab fa-facebook-f mr-1"></i> Login
                                                            </a>
                                                        </div>
                                                        <div class="col-6">
                                                            <a href="#" class="btn btn-google btn-block">
                                                                <i class="fab fa-google mr-1"></i> Login
                                                            </a>
                                                        </div>
                                                    </div>
                                                </form>
                                            )}
                                        </Formik>
                                        {/* <!-- /Register Form --> */}
                                    </div>
                                </div>
                            </div>
                            {/* <!-- /Account Content --> */}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
