import React, { useState, useEffect } from 'react';
import Auth from '../authentication/Auth';
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
  Link,
  useHistory,
} from 'react-router-dom';
import axios from 'axios';

export default function PageTwo(params) {
  const history = useHistory();
  const { setReportData } = params;

  const apiUrl = process.env.REACT_APP_BACKEND;
  const [dtype, setDtype] = useState('');
  const [ageGroup, setAgeGroup] = useState('');
  const [gender, setGender] = useState('');
  const [bmi, setBMI] = useState('');
  const [hypertension, setHypertension] = useState('');
  const [duration, setDuration] = useState('');
  const [history1, setHistory1] = useState('');
  const [smoking, setSmoking] = useState('');
  const [fastbloodsugar, setFastBloodSugar] = useState('');
  const [urinelevel, setUrineLevel] = useState('');
  const [albumin, setAlbumin] = useState('');
  const [ckd, setCKD] = useState('');
  const [bloodSugarLevel, setBloodSugarLevel] = useState('');
  const [aic, setAic] = useState('');
  const [thirsty, setThirsty] = useState('');
  const [highbloodpressure, setHighBloodPressure] = useState('');
  const [shortbreath, setShortBreath] = useState('');
  const [appatite, setAppatite] = useState('');
  const [dbloodpressure, setDBloodPressure] = useState('');
  const [sbloodpressure, setSBloodPressure] = useState('');
  const [ckd2, setCkd2] = useState('');
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    // loadUser();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();

    console.log(dtype);
    console.log(ageGroup);
    console.log(gender);
    console.log(bmi);
    console.log(hypertension);
    console.log(duration);
    console.log(history1);
    console.log(smoking);
    console.log(fastbloodsugar);
    console.log(urinelevel);
    console.log(albumin);
    console.log(ckd);
    console.log(bloodSugarLevel);
    console.log(aic);
    console.log(thirsty);
    console.log(highbloodpressure);
    console.log(shortbreath);
    console.log(appatite);
    console.log(dbloodpressure);
    console.log(sbloodpressure);

    let data = {
      dtype,
      ageGroup,
      gender,
      bmi,
      hypertension,
      duration,
      history1,
      smoking,
      fastbloodsugar,
      urinelevel,
      albumin,
      ckd,
      bloodSugarLevel,
      aic,
      thirsty,
      highbloodpressure,
      shortbreath,
      appatite,
      dbloodpressure,
      sbloodpressure,
    };

    data.page = 'diabetes';

    let requestBody = new FormData();

    requestBody.append('dtype', dtype);
    requestBody.append('ageGroup', ageGroup);
    requestBody.append('gender', gender);
    requestBody.append('bmi', bmi);
    requestBody.append('hypertension', hypertension);
    requestBody.append('duration', duration);
    requestBody.append('history1', history1);
    requestBody.append('smoking', smoking);
    requestBody.append('fastbloodsugar', fastbloodsugar);
    requestBody.append('urinelevel', urinelevel);
    requestBody.append('albumin', albumin);
    requestBody.append('ckd', ckd);
    requestBody.append('bloodSugarLevel', bloodSugarLevel);
    requestBody.append('aic', aic);
    requestBody.append('thirsty', thirsty);
    requestBody.append('highbloodpressure', highbloodpressure);
    requestBody.append('shortbreath', shortbreath);
    requestBody.append('appatite', appatite);
    requestBody.append('dbloodpressure', dbloodpressure);
    requestBody.append('sbloodpressure', sbloodpressure);

    axios
      .post(`${apiUrl}/api/v1/diabetic/predict`, requestBody, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })
      .then((response) => {
        console.log(response);
        console.log(response.data);
        var diabeticprediction = response.data.Probability_of_having_Diabetes;
        if (diabeticprediction === 'Dpresent') {
          setCkd2('Critical');
        } else if (diabeticprediction === 'Dabsent') {
          setCkd2('Not Critical');
        }

        data.result = response.data;
        // console.log(data)

        setReportData(data);
        history.push('/reportviewdiabetes');
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const loadUser = async () => {
    fetch(
      `${process.env.REACT_APP_HOSTING_URL}/users/latest-ckd-prediction/` +
        Auth.getUserId(),
      {
        method: 'GET',
        headers: new Headers({
          Accept: 'application/vnd.github.cloak-preview',
          token: Auth.getToken(),
        }),
      }
    )
      .then((res) => res.json())
      .then((response) => {
        console.log(response);
        setUserData(response);
      })
      .catch((error) => console.log(error));
  };

  return (
    <>
      {/* <!-- Breadcrumb --> */}
      <div className="breadcrumb-bar">
        <div className="container-fluid">
          <div className="row align-items-center">
            <div className="col-md-12 col-12">
              <nav aria-label="breadcrumb" className="page-breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <a href="/home">Home</a>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Blank Page
                  </li>
                </ol>
              </nav>
              <h2 className="breadcrumb-title">Blank Page</h2>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- /Breadcrumb -->    */}

      {/* <!-- Page Content --> */}
      <div className="content">
        <>
          {/* <!-- Breadcrumb --> */}

          <div className="breadcrumb-bar">
            <div className="container-fluid">
              <div className="row align-items-center">
                <div className="col-md-12 col-12">
                  <nav aria-label="breadcrumb" className="page-breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <a href="/home">Home</a>
                      </li>
                      <li
                        className="breadcrumb-item active"
                        aria-current="page">
                        Risk Analysis and Prediction
                      </li>
                    </ol>
                  </nav>
                  <h2 className="breadcrumb-title">Diabetes Mellitus</h2>
                </div>
              </div>
            </div>
          </div>
          {/* <!-- /Breadcrumb -->    */}
        </>
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-8" style={{ marginLeft: '18%' }}>
              <div className="card">
                <form action="#">
                  <div className="card">
                    <div className="card-header text-center">
                      <div
                        className="alert alert-success alert-dismissible fade show"
                        role="alert">
                        <strong>Personal Information Province</strong>
                      </div>
                    </div>

                    <div className="card-body">
                      <div className="row">
                        <div className="col-xl-6">
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Age Group
                            </label>
                            <div className="col-lg-9">
                              <select
                                className="form-control"
                                onChange={(e) => setAgeGroup(e.target.value)}>
                                <option>-- Select --</option>
                                <option value="below 60">Below 60</option>
                                <option value="over 60">Over 60</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Diabetes Type
                            </label>
                            <div className="col-lg-9">
                              <select
                                className="form-control"
                                onChange={(e) => setDtype(e.target.value)}>
                                <option>-- Select --</option>
                                <option value="1">Type 1</option>
                                <option value="2">Type 2 </option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Gender
                            </label>
                            <div className="col-lg-9">
                              <div className="form-check form-check-inline">
                                <input
                                  className="form-check-input"
                                  type="radio"
                                  name="gender"
                                  id="gender_male"
                                  value="male"
                                  onChange={(e) => setGender(e.target.value)}
                                />
                                <label
                                  className="form-check-label"
                                  for="gender_male">
                                  Male
                                </label>
                              </div>
                              <div className="form-check form-check-inline">
                                <input
                                  className="form-check-input"
                                  type="radio"
                                  name="gender"
                                  id="gender_female"
                                  value="female"
                                  onChange={(e) => setGender(e.target.value)}
                                />
                                <label
                                  className="form-check-label"
                                  for="gender_female">
                                  Female
                                </label>
                              </div>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              BMI
                            </label>
                            <div className="col-lg-9">
                              <select
                                className="form-control"
                                onChange={(e) => setBMI(e.target.value)}>
                                <option>-- Select --</option>
                                <option value="Normal">Normal</option>
                                <option value="underweight">
                                  Under Weight
                                </option>
                                <option value="Obese">Obese</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Diabetes Duration (years)
                            </label>
                            <div className="col-lg-9">
                              <select
                                className="form-control"
                                onChange={(e) => setDuration(e.target.value)}>
                                <option>-- Select --</option>
                                <option value="below 10">Below 10</option>
                                <option value="over 10">Over 10</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Urine Level
                            </label>
                            <div className="col-lg-9">
                              <select
                                className="form-control "
                                onChange={(e) => setUrineLevel(e.target.value)}>
                                <option value="0">-- Select --</option>
                                <option value="below 40">below 40</option>
                                <option value="over 40">Over 40</option>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div className="col-xl-6">
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Fast Blood Sugar Level
                            </label>
                            <div className="col-lg-9">
                              <select
                                className="form-control"
                                onChange={(e) =>
                                  setFastBloodSugar(e.target.value)
                                }>
                                <option>-- Select --</option>
                                <option value="99 below">Below 99 mm Hg</option>
                                <option value="100-125">100-125 mm Hg</option>
                                <option value="over126">Over 126 mm Hg</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              AIC report status
                            </label>
                            <div className="col-lg-9">
                              <select
                                className="form-control "
                                onChange={(e) => setAic(e.target.value)}>
                                <option value="0">-- Select --</option>
                                <option value="below 5.7">Below 5.7</option>
                                <option value="5.7-6.4">5.7-6.4</option>
                                <option value="above 6.5">Above 6.5</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Diastolic Blood Pressure
                            </label>
                            <div className="col-lg-9">
                              <select
                                className="form-control "
                                onChange={(e) =>
                                  setDBloodPressure(e.target.value)
                                }>
                                <option value="0">-- Select --</option>
                                <option value="below 80">Below 80</option>
                                <option value="90-100">90-100</option>
                                <option value="100-120">100-120</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Systolic Blood Pressure
                            </label>
                            <div className="col-lg-9">
                              <select
                                className="form-control "
                                onChange={(e) =>
                                  setSBloodPressure(e.target.value)
                                }>
                                <option value="0">-- Select --</option>
                                <option value="below 90">Below 90</option>
                                <option value="120-140">120-140</option>
                                <option value="above 140">Above 140</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Blood Sugar Level
                            </label>
                            <div className="col-lg-9">
                              <select
                                className="form-control "
                                onChange={(e) =>
                                  setBloodSugarLevel(e.target.value)
                                }>
                                <option value="0">-- Select --</option>
                                <option value="70-150">70-150</option>
                                <option value="over 150">Over 150</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="card">
                    <div className="card-header text-center">
                      <div
                        className="alert alert-primary alert-dismissible fade show"
                        role="alert">
                        <strong>Symptoms Related Information</strong>
                      </div>
                    </div>

                    <div className="card-body">
                      <div className="row">
                        {/* <!-- Invoice Item --> */}
                        <div className="col-md-12 text-center">
                          <div className="invoice-item invoice-table-wrap">
                            <div className="row">
                              <div className="col-md-12">
                                <div className="table-responsive">
                                  <table className="invoice-table table table-bordered">
                                    <thead>
                                      <tr>
                                        <th>Description</th>
                                        <th>Yes</th>
                                        <th>No</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td>Do you have Hypertension?</td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline text-center">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="hypertension"
                                              id="hypertension-y"
                                              value="yes"
                                              onChange={(e) =>
                                                setHypertension(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="hypertension"
                                              id="hypertension-n"
                                              value="no"
                                              onChange={(e) =>
                                                setHypertension(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>
                                          Do you or your family members have
                                          history in developing CKD?
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline text-center">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="history1"
                                              id="history1-y"
                                              value="yes"
                                              onChange={(e) =>
                                                setHistory1(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="history1"
                                              id="history1-n"
                                              value="no"
                                              onChange={(e) =>
                                                setHistory1(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>
                                          Do you have any other kidney problems?
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline text-center">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="ckd"
                                              id="ckd-y"
                                              value="yes"
                                              onChange={(e) =>
                                                setCKD(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="ckd"
                                              id="ckd-n"
                                              value="no"
                                              onChange={(e) =>
                                                setCKD(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>Do you have smoking habits?</td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline text-center">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="smoking"
                                              id="smoking-y"
                                              value="yes"
                                              onChange={(e) =>
                                                setSmoking(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="smoking"
                                              id="smoking-n"
                                              value="no"
                                              onChange={(e) =>
                                                setSmoking(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>
                                          Any albumin content in urin sample
                                          reports
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline text-center">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="albumin"
                                              id="albumin-y"
                                              value="positive"
                                              onChange={(e) =>
                                                setAlbumin(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="albumin"
                                              id="albumin-n"
                                              value="negative"
                                              onChange={(e) =>
                                                setAlbumin(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>
                                          Do you feel any thirsty regulary?
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline text-center">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="thirsty"
                                              id="thirsty-y"
                                              value="yes"
                                              onChange={(e) =>
                                                setThirsty(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="foaming"
                                              id="foaming-n"
                                              value="no"
                                              onChange={(e) =>
                                                setThirsty(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>Do you have high blood pressure</td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline text-center">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="highbloodpressure"
                                              id="highbloodpressure-y"
                                              value="yes"
                                              onChange={(e) =>
                                                setHighBloodPressure(
                                                  e.target.value
                                                )
                                              }
                                            />
                                          </div>
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="highbloodpressure"
                                              id="highbloodpressure-n"
                                              value="no"
                                              onChange={(e) =>
                                                setHighBloodPressure(
                                                  e.target.value
                                                )
                                              }
                                            />
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>Short Breath </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline text-center">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="breath"
                                              id="breath-y"
                                              value="yes"
                                              onChange={(e) =>
                                                setShortBreath(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="breath"
                                              id="breath-n"
                                              value="no"
                                              onChange={(e) =>
                                                setShortBreath(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                      </tr>

                                      <tr>
                                        <td>Loss Appatite</td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline text-center">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="appatite"
                                              id="appatite-y"
                                              value="yes"
                                              onChange={(e) =>
                                                setAppatite(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                        <td className="text-center">
                                          {' '}
                                          <div className="form-check form-check-inline">
                                            <input
                                              className="form-check-input"
                                              type="radio"
                                              name="appatite"
                                              id="appatite-n"
                                              value="no"
                                              onChange={(e) =>
                                                setAppatite(e.target.value)
                                              }
                                            />
                                          </div>
                                        </td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                              <br></br>
                            </div>
                          </div>
                        </div>
                        {/* <!-- /Invoice Item --> */}
                      </div>
                    </div>
                    <div className="col-6 col-sm-4 col-md-2 col-xl mb-3 mb-xl-0 text-right">
                      {/* <Link to="/reportview"> */}
                      <button
                        type="submit"
                        className="btn btn-outline-primary active"
                        far
                        icon="paper-plane"
                        onClick={(e) => handleSubmit(e)}>
                        Genarate Status Report
                      </button>
                      {/* </Link> */}
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
