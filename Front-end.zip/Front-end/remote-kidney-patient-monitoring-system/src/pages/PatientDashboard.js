import React, { useEffect, useState } from 'react';

import {
    BrowserRouter as Router,
    Route,
    Switch,
    Redirect,
    Link,
} from "react-router-dom";

import Auth from '../authentication/Auth';
import axios from 'axios';

export default function ReportView(params) {
    const { reportData } = params;
    const [formData, setformData] = useState(null);

    const [user, setUser] = useState('');
    const [ckdDiabetes, setCkdDiabetes] = useState('');
    const [ckdElder, setCkdElder] = useState('');
    const [ckdRural, setCkdRural] = useState('');
    const [ckdTransplant, setCkdTransplant] = useState('');

    const [ckdDiabetesArray, setCkdDiabetesArray] = useState([]);
    const [ckdElderArray, setCkdElderArray] = useState([]);
    const [ckdRuralArray, setCkdRuralArray] = useState([]);
    const [ckdTransplantArray, setCkdTransplantArray] = useState([]);

    const [firstName, setFirstName] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState('');
    const [city, setCity] = useState('');

    useEffect(() => {
        console.log(reportData);
        setformData(reportData);
    }, [])

    useEffect(() => {
        let userId = Auth.getUserId();
  
        axios
          .get(`${process.env.REACT_APP_HOSTING_URL}/helper/users/${userId}`)
          .then((response) => {
            setFirstName(response.data.name);
            setDateOfBirth(response.data.dateOfBirth);
            setCity(response.data.city);
          })
          .catch((err) => {
            console.log(err);
          });
      }, []);

    useEffect(() => {
      let userId = Auth.getUserId();

      axios
        .get(`${process.env.REACT_APP_HOSTING_URL}/helper/users/${userId}`)
        .then((response) => {
          console.log(response.data);
          setUser(response.data);

          let ckdDiabetes = response.data.prediction_history_ckddiabetes;
          let ckdElder = response.data.prediction_history_ckdelder;
          let ckdRural = response.data.prediction_history_ckdrural;
          let ckdTransplant = response.data.prediction_history_ckdtransplant;

        //   console.log(ckdDiabetes[ckdDiabetes.length - 1])
        //   console.log(ckdElder[ckdElder.length - 1])
        //   console.log(ckdRural[ckdRural.length - 1])
        //   console.log(ckdTransplant[ckdTransplant.length - 1])

          setCkdDiabetes(ckdDiabetes[ckdDiabetes.length - 1])
          setCkdElder(ckdElder[ckdElder.length - 1])
          setCkdRural(ckdRural[ckdRural.length - 1])
          setCkdTransplant(ckdTransplant[ckdTransplant.length - 1])

          setCkdDiabetesArray(ckdDiabetes ? ckdDiabetes : [])
          setCkdElderArray(ckdElder ? ckdElder : [])
          setCkdRuralArray(ckdRural ? ckdRural : [])
          setCkdTransplantArray(ckdTransplant ? ckdTransplant : [])
        })
        .catch((err) => {
          console.log(err);
        });
    }, [])

    const goToDiabetesReport = () => {
        alert('diabetes report')
    }

    return (
        <>
            {/* <!-- Breadcrumb --> */}
            <div class="breadcrumb-bar">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-md-12 col-12">
                            <nav aria-label="breadcrumb" class="page-breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="/home">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Blank Page
                                    </li>
                                </ol>
                            </nav>
                            <h2 class="breadcrumb-title">Blank Page</h2>
                        </div>
                    </div>
                </div>
            </div>
            {/* <!-- /Breadcrumb -->    */}

            <div class="content">
                <>
                    {/* <!-- Breadcrumb --> */}
                    <div class="breadcrumb-bar">
                        <div class="container-fluid">
                            <div class="row align-items-center">
                                <div class="col-md-12 col-12">
                                    <nav aria-label="breadcrumb" class="page-breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="/home">Home</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">

                                            </li>
                                        </ol>
                                    </nav>
                                    <h2 class="breadcrumb-title">Patient Dashboard</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* <!-- /Breadcrumb -->    */}
                </>

                <div class="container-fluid">

                    <div class="row">

                        {/* <!-- Profile Sidebar --> */}
                        <div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
                            <div class="profile-sidebar">
                                <div class="widget-profile pro-widget-content">
                                    <div class="profile-info-widget">
                                        <a href="#" class="booking-doc-img">
                                            <img src="assets/img/ava.jpg" alt="User Image" />
                                        </a>
                                        <div class="profile-det-info">
                                            <h3>{firstName}</h3>
                                            <div class="patient-details">
                                                <h5><i class="fas fa-birthday-cake"></i>{dateOfBirth}</h5>
                                                <h5 class="mb-0"><i class="fas fa-map-marker-alt"></i>{city}</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="dashboard-widget">
                                    <nav class="dashboard-menu">
                                        <ul>
                                            <li>
                                                <a href="/patient_dashboard">
                                                    <i class="fas fa-columns"></i>
                                                    <span>Dashboard</span>
                                                </a>
                                            </li>


                                            <li>
                                                <a href="/patient_profile">
                                                    <i class="fas fa-user-cog"></i>
                                                    <span>Profile Settings</span>
                                                </a>
                                            </li>

                                            <li>
                                                <a href="index.html">
                                                    <i class="fas fa-sign-out-alt"></i>
                                                    <span>Logout</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>

                            </div>
                        </div>
                        {/* <!-- /Profile Sidebar --> */}

                        <div class="col-md-7 col-lg-8 col-xl-9">
                            <div class="card">
                                <div class="card-body pt-0">

                                    {/* <!-- Tab Menu --> */}
                                    <nav class="user-tabs mb-4">
                                        <ul class="nav nav-tabs nav-tabs-bottom nav-justified">
                                            <li class="nav-item">
                                                <a class="nav-link active" href="#pat_appointments" data-toggle="tab">Latest Status</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="#pat_prescriptions" data-toggle="tab">Status History</a>
                                            </li>

                                        </ul>
                                    </nav>
                                    {/* <!-- /Tab Menu --> */}

                                    {/* <!-- Tab Content --> */}
                                    <div class="tab-content pt-0">

                                        {/* <!-- Appointment Tab --> */}
                                        <div id="pat_appointments" class="tab-pane fade show active">
                                            <div class="card card-table mb-0">
                                                <div class="card-body">
                                                    <div class="table-responsive">
                                                        <table class="table table-hover table-center mb-0">

                                                            <tbody>
                                                                {/* <tr>
                                                                    <td>
                                                                        <h2 class="table-avatar">
                                                                            <a href="doctor-profile.html" class="avatar avatar-sm mr-2">
                                                                                <img class="avatar-img rounded-circle" src="assets/img/doctors/doctor-thumb-01.jpg" alt="User Image" />
                                                                            </a>
                                                                            <a href="doctor-profile.html">Dr. Diedra Spangler <span>Dental</span></a>
                                                                        </h2>
                                                                    </td>
                                                                    <td>14 Nov 2020 <span class="d-block text-info">10.00 AM</span></td>
                                                                    <td>12 Nov 2020</td>
                                                                    <td>$200</td>
                                                                    <td>16 Nov 2020</td>
                                                                    <td><span class="badge badge-pill bg-success-light">Confirm</span></td>
                                                                    <td class="text-right">
                                                                        <div class="table-action">
                                                                            <a href="javascript:void(0);" class="btn btn-sm bg-primary-light">
                                                                                <i class="fas fa-print"></i> Print
                                                                            </a>
                                                                            <a href="javascript:void(0);" class="btn btn-sm bg-info-light">
                                                                                <i class="far fa-eye"></i> View
                                                                            </a>
                                                                        </div>
                                                                    </td>
                                                                </tr> */}
                                                       {ckdDiabetes? (<tr>
                                                           <td><strong>Diabetic Mellitus</strong> <br/> <em style={{fontSize: 13}}>Category</em></td>
                                                           <td>{ckdDiabetes.initial_Prediction3 === 'Dpresent'? 
                                                           <span className="badge badge-pill bg-danger-light">Critical</span> : 
                                                           <span className="badge badge-pill bg-success-light">Not Critical</span>}
                                                           </td>
                                                           <td>{ckdDiabetes.time}</td>
                                                        <td class="text-right">
                                                            <div class="table-action">
                                                                <a className="btn btn-sm bg-primary-light">
                                                                    <i className="fas fa-print"></i> Print
                                                                </a>
                                                                <button className="btn btn-sm bg-info-light" onClick={() => goToDiabetesReport()}>
                                                                    <i className="far fa-eye"></i> View
                                                                </button>
                                                            </div>
                                                        </td>
                                                       </tr>): ''}
                                                       {ckdRural? (<tr>
                                                           <td><strong>CKD Risk Analysis</strong> <br/> <em style={{fontSize: 13}}>Category</em></td>
                                                           <td>{ckdRural.initial_Prediction === '1'? 
                                                           <span className="badge badge-pill bg-danger-light">Critical</span> : 
                                                           <span className="badge badge-pill bg-success-light">Not Critical</span>}
                                                           </td>
                                                           <td>{ckdRural.time}</td>
                                                        <td class="text-right">
                                                            <div class="table-action">
                                                                <a className="btn btn-sm bg-primary-light">
                                                                    <i className="fas fa-print"></i> Print
                                                                </a>
                                                                <a className="btn btn-sm bg-info-light">
                                                                    <i className="far fa-eye"></i> View
                                                                </a>
                                                            </div>
                                                        </td>
                                                       </tr>): ''}
                                                       {ckdElder? (<tr>
                                                           <td><strong>Elderly Patient</strong> <br/> <em style={{fontSize: 13}}>Category</em></td>
                                                           <td>{ckdElder.initial_Prediction1 === 'Critical Patient'? 
                                                           <span className="badge badge-pill bg-danger-light">Critical</span> : 
                                                           <span className="badge badge-pill bg-success-light">Not Critical</span>}
                                                           </td>
                                                           <td>{ckdElder.time}</td>
                                                        <td class="text-right">
                                                            <div class="table-action">
                                                                <a className="btn btn-sm bg-primary-light">
                                                                    <i className="fas fa-print"></i> Print
                                                                </a>
                                                                <a className="btn btn-sm bg-info-light">
                                                                    <i className="far fa-eye"></i> View
                                                                </a>
                                                            </div>
                                                        </td>
                                                       </tr>): ''}
                                                       {ckdTransplant? (<tr>
                                                           <td><strong>Transpalnt Patient</strong> <br/> <em style={{fontSize: 13}}>Category</em></td>
                                                           <td>{ckdTransplant.initial_Prediction2 === 'Yes'? 
                                                           <span className="badge badge-pill bg-danger-light">Critical</span> : 
                                                           <span className="badge badge-pill bg-success-light">Not Critical</span>}
                                                           </td>
                                                           <td>{ckdTransplant.time}</td>
                                                        <td class="text-right">
                                                            <div class="table-action">
                                                                <a className="btn btn-sm bg-primary-light">
                                                                    <i className="fas fa-print"></i> Print
                                                                </a>
                                                                <a className="btn btn-sm bg-info-light">
                                                                    <i className="far fa-eye"></i> View
                                                                </a>
                                                            </div>
                                                        </td>
                                                       </tr>): ''}

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {/* <!-- /Appointment Tab --> */}

                                        {/* <!-- Prescription Tab --> */}
                                        <div class="tab-pane fade" id="pat_prescriptions">
                                            <div class="card card-table mb-0">
                                                <div class="card-body">
                                                    <div class="table-responsive">
                                                        <table class="table table-hover table-center mb-0">

                                                            <tbody>
                                                                {/* <tr>
                                                                    <td>14 Nov 2020</td>
                                                                    <td>Prescription 1</td>
                                                                    <td>
                                                                        <h2 class="table-avatar">
                                                                            <a href="doctor-profile.html" class="avatar avatar-sm mr-2">
                                                                                <img class="avatar-img rounded-circle" src="assets/img/doctors/doctor-thumb-01.jpg" alt="User Image" />
                                                                            </a>
                                                                            <a href="doctor-profile.html">Dr. Diedra Spangler <span>Dental</span></a>
                                                                        </h2>
                                                                    </td>
                                                                    <td class="text-right">
                                                                        <div class="table-action">
                                                                            <a href="javascript:void(0);" class="btn btn-sm bg-primary-light">
                                                                                <i class="fas fa-print"></i> Print
                                                                            </a>
                                                                            <a href="javascript:void(0);" class="btn btn-sm bg-info-light">
                                                                                <i class="far fa-eye"></i> View
                                                                            </a>
                                                                        </div>
                                                                    </td>
                                                                </tr> */}
                                                                {ckdDiabetesArray.map((result, index) => {
                                                                       return (<tr key={index}>
                                                                            <td><strong>Diabetic Mellitus</strong> <br/> <em style={{fontSize: 15}}>Category</em></td>
                                                                            <td>{result.initial_Prediction3 === 'Dpresent'? 
                                                                            <span className="badge badge-pill bg-danger-light">Critical</span> : 
                                                                            <span className="badge badge-pill bg-success-light">Not Critical</span>}
                                                                            </td>
                                                                            <td>{result.time}</td>
                                                                         <td class="text-right">
                                                                             <div class="table-action">
                                                                                 <a className="btn btn-sm bg-primary-light">
                                                                                     <i className="fas fa-print"></i> Print
                                                                                 </a>
                                                                                
                                                                                 <a className="btn btn-sm bg-info-light">
                                                                                     <i className="far fa-eye"></i> View
                                                                                 </a>
                                                                             </div>
                                                                         </td>
                                                                        </tr>)
                                                                })}
                                                                {ckdRuralArray.map((result, index) => {
                                                                       return (<tr key={index}>
                                                                            <td><strong>CKD Risk Analysis</strong> <br/> <em style={{fontSize: 15}}>Category</em></td>
                                                                            <td>{result.initial_Prediction === '1' ? 
                                                                            <span className="badge badge-pill bg-danger-light">Critical</span> : 
                                                                            <span className="badge badge-pill bg-success-light">Not Critical</span>}
                                                                            </td>
                                                                            <td>{result.time}</td>
                                                                         <td class="text-right">
                                                                             <div class="table-action">
                                                                                 <a className="btn btn-sm bg-primary-light">
                                                                                     <i className="fas fa-print"></i> Print
                                                                                 </a>

                                                                                 <a className="btn btn-sm bg-info-light">
                                                                                     <i className="far fa-eye"></i> View
                                                                                 </a>
                                                                             </div>
                                                                         </td>
                                                                        </tr>)
                                                                })}
                                                                {ckdElderArray.map((result, index) => {
                                                                       return (<tr key={index}>
                                                                            <td><strong>Elderly Patient</strong> <br/> <em style={{fontSize: 15}}>Category</em></td>
                                                                            <td>{result.initial_Prediction1 === 'Critical Patient' ? 
                                                                            <span className="badge badge-pill bg-danger-light">Critical</span> : 
                                                                            <span className="badge badge-pill bg-success-light">Not Critical</span>}
                                                                            </td>
                                                                            <td>{result.time}</td>
                                                                         <td class="text-right">
                                                                             <div class="table-action">
                                                                                 <a className="btn btn-sm bg-primary-light">
                                                                                     <i className="fas fa-print"></i> Print
                                                                                 </a>

                                                                                 <a className="btn btn-sm bg-info-light">
                                                                                     <i className="far fa-eye"></i> View
                                                                                 </a>
                                                                             </div>
                                                                         </td>
                                                                        </tr>)
                                                                })}
                                                                {ckdTransplantArray.map((result, index) => {
                                                                       return (<tr key={index}>
                                                                            <td><strong>Transpalnt Patient</strong> <br/> <em style={{fontSize: 15}}>Category</em></td>
                                                                            <td>{result.initial_Prediction2 === 'Yes' ? 
                                                                            <span className="badge badge-pill bg-danger-light">Critical</span> : 
                                                                            <span className="badge badge-pill bg-success-light">Not Critical</span>}
                                                                            </td>
                                                                            <td>{result.time}</td>
                                                                         <td class="text-right">
                                                                             <div class="table-action">
                                                                                 <a className="btn btn-sm bg-primary-light">
                                                                                     <i className="fas fa-print"></i> Print
                                                                                 </a>

                                                                                 <a className="btn btn-sm bg-info-light">
                                                                                     <i className="far fa-eye"></i> View
                                                                                 </a>
                                                                             </div>
                                                                         </td>
                                                                        </tr>)
                                                                })}
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {/* <!-- /Prescription Tab --> */}





                                    </div>
                                    {/* <!-- Tab Content --> */}

                                </div>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </>


    )
}
