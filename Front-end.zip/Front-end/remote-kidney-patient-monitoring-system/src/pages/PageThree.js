import React, { useState, useEffect } from "react";
import Auth from '../authentication/Auth';
import {
    BrowserRouter as Router,
    Route,
    Switch,
    Redirect,
    Link,
    useHistory
} from "react-router-dom";
import axios from "axios";

export default function PageOne(params) {
    const history = useHistory();
    const { setReportData } = params;
    const apiUrl = process.env.REACT_APP_BACKEND;
    const [gender, setGender] = useState('')
    const [age, setAge] = useState('')
    const [kidney_period, setKidney_period] = useState('')
    const [blood_pressure, setBlood_pressure] = useState('')
    const [nausea, setNausea] = useState('')
    const [vomit, setVomit] = useState('')
    const [loss_of_appetite, setLoss_of_appetite] = useState('')
    const [itching, setItching] = useState('')
    const [hiccups, setHiccups] = useState('')
    const [metallic_taste, setMetallic_taste] = useState('')
    const [fatigue, setFatigue] = useState('')
    const [Sleeping_difficulty, setSleeping_difficulty1] = useState('')
    const [urinate_change, setUrinate_change] = useState('')
    const [mental_sharpness, setMental_sharpness] = useState('')
    const [muscle_twitches, setMuscle_twitches] = useState('')
    const [swelling, setSwelling] = useState('')
    const [hypertension, setHypertension] = useState('')
    const [userData, setUserData] = useState(null);

    useEffect(() => {
        // loadUser();

    }, []);    

    const handleSubmit = (e) => {
        e.preventDefault();

        console.log(gender)
        console.log(age)
        console.log(kidney_period)
        console.log(blood_pressure)
        console.log(nausea)
        console.log(vomit)
        console.log(loss_of_appetite)
        console.log(itching)
        console.log(hiccups)
        console.log(metallic_taste)
        console.log(fatigue)
        console.log(Sleeping_difficulty)
        console.log(urinate_change)
        console.log(mental_sharpness)
        console.log(muscle_twitches)
        console.log(swelling)
        console.log(hypertension)

        let data = {
            gender,
            age,
            kidney_period,
            blood_pressure,
            nausea,
            vomit,
            loss_of_appetite,
            itching,
            hiccups,
            metallic_taste,
            fatigue,
            Sleeping_difficulty,
            urinate_change,
            mental_sharpness,
            muscle_twitches,
            swelling,
            hypertension
        }

        data.page = 'ktm'

        let requestBody = new FormData()

        requestBody.append('gender', gender)
        requestBody.append('age', age)
        requestBody.append('kidney_period', kidney_period)
        requestBody.append('blood_pressure', blood_pressure)
        requestBody.append('nausea', nausea)
        requestBody.append('vomit', vomit)
        requestBody.append('loss_of_appetite', loss_of_appetite)
        requestBody.append('itching', itching)
        requestBody.append('hiccups', hiccups)
        requestBody.append('metallic_taste', metallic_taste)
        requestBody.append('fatigue', fatigue)
        requestBody.append('Sleeping_difficulty', Sleeping_difficulty)
        requestBody.append('urinate_change', urinate_change)
        requestBody.append('mental_sharpness', mental_sharpness)
        requestBody.append('muscle_twitches', muscle_twitches)
        requestBody.append('swelling', swelling)
        requestBody.append('hypertension', hypertension)


        axios.post(`${apiUrl}/api/v1/ktm/final_status`, requestBody, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        }).then((response) => {
            console.log(response)
            console.log(response.data)
            data.result = response.data;
            // console.log(data)
            setReportData(data)
            history.push('/reportviewthree')
        }).catch((err) => {
            console.log(err)
        });
    };

    const loadUser = async () => {
        fetch(
          `${process.env.REACT_APP_HOSTING_URL}/users/latest-ckd-prediction/` +
            Auth.getUserId(),
          {
            method: 'GET',
            headers: new Headers({
              Accept: 'application/vnd.github.cloak-preview',
              token: Auth.getToken(),
            }),
          }
        )
          .then((res) => res.json())
          .then((response) => {
            console.log(response);
            setUserData(response);
          })
          .catch((error) => console.log(error));
      };


    return (
        <>
            {/* <!-- Breadcrumb --> */}
            <div className="breadcrumb-bar">
                <div className="container-fluid">
                    <div className="row align-items-center">
                        <div className="col-md-12 col-12">
                            <nav aria-label="breadcrumb" className="page-breadcrumb">
                                <ol className="breadcrumb">
                                    <li className="breadcrumb-item">
                                        <a href="/home">Home</a>
                                    </li>
                                    <li className="breadcrumb-item active" aria-current="page">
                                        Blank Page
                                    </li>
                                </ol>
                            </nav>
                            <h2 className="breadcrumb-title">Blank Page</h2>
                        </div>
                    </div>
                </div>
            </div>
            {/* <!-- /Breadcrumb -->    */}

            {/* <!-- Page Content --> */}
            <div className="content">
                <>
                    {/* <!-- Breadcrumb --> */}

                    <div className="breadcrumb-bar">
                        <div className="container-fluid">
                            <div className="row align-items-center">
                                <div className="col-md-12 col-12">
                                    <nav aria-label="breadcrumb" className="page-breadcrumb">
                                        <ol className="breadcrumb">
                                            <li className="breadcrumb-item">
                                                <a href="/home">Home</a>
                                            </li>
                                            <li className="breadcrumb-item active" aria-current="page">
                                                Risk Analysis and Prediction
                                            </li>
                                        </ol>
                                    </nav>
                                    <h2 className="breadcrumb-title">Elder Patient</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* <!-- /Breadcrumb -->    */}
                </>
                <div className="container-fluid">

                    <div className="row">
                        <div className="col-md-8" style={{ marginLeft: "18%" }}>
                            <div className="card">
                                <form action="#">
                                    <div className="card">

                                        <div className="card-header text-center">
                                            <div className="alert alert-success alert-dismissible fade show" role="alert">

                                                <strong>Personal Information of Elderly Patient</strong>


                                            </div>

                                        </div>

                                        <div className="card-body">

                                            <div className="row">
                                                <div className="col-xl-6">
                                                    <div className="form-group row">
                                                        <label className="col-lg-3 col-form-label">
                                                            Gender
                                                        </label>
                                                        <div className="col-lg-9">
                                                            <div className="form-check form-check-inline" >
                                                                <input
                                                                    className="form-check-input"
                                                                    type="radio"
                                                                    name="gender"
                                                                    id="gender_male"
                                                                    value="Male"
                                                                    onChange={(e) => setGender(e.target.value)}
                                                                />
                                                                <label
                                                                    className="form-check-label"
                                                                    for="gender_male"
                                                                >
                                                                    Male
                                                                </label>
                                                            </div>
                                                            <div className="form-check form-check-inline">
                                                                <input
                                                                    className="form-check-input"
                                                                    type="radio"
                                                                    name="gender"
                                                                    id="gender_female"
                                                                    value="Female"
                                                                    onChange={(e) => setGender(e.target.value)}
                                                                />
                                                                <label
                                                                    className="form-check-label"
                                                                    for="gender_female"
                                                                >
                                                                    Female
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="form-group row">
                                                        <label className="col-lg-3 col-form-label">
                                                            Age Group
                                                        </label>
                                                        <div className="col-lg-9">
                                                            <select className="form-control" onChange={(e) => setAge(e.target.value)}>
                                                                <option>-- Select --</option>
                                                                <option value="55 - 64 years">55 - 64 years</option>
                                                                <option value="65 - 74 years">65 - 74 years</option>
                                                                <option value="75 - 84 years">75 - 84 years</option>
                                                                <option value="85 - 94 years">85 - 94 years</option>
                                                                <option value="Above 95 years">Above 95 years</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div className="form-group row">
                                                        <label className="col-lg-3 col-form-label">
                                                            Kidney Period
                                                        </label>
                                                        <div className="col-lg-9">
                                                            <select className="form-control" onChange={(e) => setKidney_period(e.target.value)}>
                                                                <option>-- Select --</option>
                                                                <option value="Below 1 year">Below 1 year</option>
                                                                <option value="1 - 3 years">1 - 3 years</option>
                                                                <option value="4 - 6 years">4 - 6 years</option>
                                                                <option value="Above 7 years">Above 7 years</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div className="col-xl-6">
                                                    <div className="form-group row">
                                                        <label className="col-lg-3 col-form-label">
                                                            Blood Pressure Level
                                                        </label>
                                                        <div className="col-lg-9">
                                                            <select className="form-control" onChange={(e) => setBlood_pressure(e.target.value)}>
                                                                <option>-- Select --</option>
                                                                <option value="< 120 mm Hg">{`< 120 mm Hg`}</option>
                                                                <option value="120 - 139 mm Hg">120 - 139 mm Hg</option>
                                                                <option value="140 - 159 mm Hg">140 - 159 mm Hg</option>
                                                                <option value="160 - 179 mm Hg">160 - 179 mm Hg</option>
                                                                <option value=">= 180 mm Hg">{`>= 180 mm Hg`}</option>
                                                            </select>
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="card">

                                        <div className="card-header text-center">
                                            <div className="alert alert-primary alert-dismissible fade show" role="alert">

                                                <strong>Symptoms Related Information</strong>

                                            </div>

                                        </div>

                                        <div className="card-body">

                                            <div className="row">
                                                {/* <!-- Invoice Item --> */}
                                                <div className="col-md-12 text-center">
                                                    <div className="invoice-item invoice-table-wrap">
                                                        <div className="row">
                                                            <div className="col-md-12">
                                                                <div className="table-responsive">
                                                                    <table className="invoice-table table table-bordered">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>Description</th>
                                                                                <th>Yes</th>
                                                                                <th>No</th>

                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td> Do you have frequent nausea ?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="home"
                                                                                        id="home-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setNausea(e.target.value)}
                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="home"
                                                                                        id="home-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setNausea(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Do you have frequent vomit ?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="sleep"
                                                                                        id="sleep-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setVomit(e.target.value)}
                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="sleep"
                                                                                        id="sleep-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setVomit(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Do you have a loss of appetite ?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="skin"
                                                                                        id="skin-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setLoss_of_appetite(e.target.value)}
                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="skin"
                                                                                        id="skin-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setLoss_of_appetite(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Is there a persistent itching in your skin ?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="urine"
                                                                                        id="urine-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setItching(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="urine"
                                                                                        id="urine-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setItching(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td> Do you have frequent hiccups ?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="foaming"
                                                                                        id="foaming-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setHiccups(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="foaming"
                                                                                        id="foaming-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setHiccups(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Is there metallic taste in your mouth ?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="eyes"
                                                                                        id="eyes-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setMetallic_taste(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="eyes"
                                                                                        id="eyes-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setMetallic_taste(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Have you feel fatigue and weakness ? </td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="appetite"
                                                                                        id="appetite-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setFatigue(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="appetite"
                                                                                        id="appetite-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setFatigue(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td> Do you have difficulties of sleeping ?{" "}</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="cramps"
                                                                                        id="cramps-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setSleeping_difficulty1(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="cramps"
                                                                                        id="cramps-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setSleeping_difficulty1(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Are there any changes in how much you urinate ?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="filtered"
                                                                                        id="filtered-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setUrinate_change(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="filtered"
                                                                                        id="filtered-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setUrinate_change(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Have you feel decreased mental sharpness ?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="itching"
                                                                                        id="itching-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setMental_sharpness(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="itching"
                                                                                        id="itching-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setMental_sharpness(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>  Do you have frequent muscle cramps / muscle twitches ?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="urination"
                                                                                        id="urination-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setMuscle_twitches(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="urination"
                                                                                        id="urination-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setMuscle_twitches(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>  Are there Swelling of feet and ankles ?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="chemicals"
                                                                                        id="chemicals-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setSwelling(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="chemicals"
                                                                                        id="chemicals-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setSwelling(e.target.value)}

                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Is there any difficulty in controlling high blood pressure (hypertension) ?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="pain"
                                                                                        id="pain-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setHypertension(e.target.value)}


                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="pain"
                                                                                        id="pain-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setHypertension(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>


                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                            <br></br>

                                                        </div>


                                                    </div>

                                                </div>
                                                {/* <!-- /Invoice Item --> */}




                                            </div>
                                        </div>
                                        <div className="col-6 col-sm-4 col-md-2 col-xl mb-3 mb-xl-0 text-right">
                                            {/* <Link to="/reportview"> */}
                                            <button type="submit" className="btn btn-outline-primary active" far icon="paper-plane" onClick={(e) => handleSubmit(e)}>
                                                Genarate Status Report
                                            </button>
                                            {/* </Link> */}
                                        </div>
                                    </div>



                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}


