import React, { useState, useEffect } from "react";
import Auth from '../authentication/Auth';
import {
    BrowserRouter as Router,
    Route,
    Switch,
    Redirect,
    Link,
    useHistory
} from "react-router-dom";
import axios from "axios";

export default function PageFour(params) {
    const history = useHistory();
    const { setReportData } = params;
    const apiUrl = process.env.REACT_APP_BACKEND;
    const [Gender, setGender] = useState('')
    const [TimeDu, setTimeDu] = useState('')
    const [Flu, setFlu] = useState('')
    const [chills, setChills] = useState('')
    const [Body_aches, setBody_aches] = useState('')
    const [dizziness, setDizziness] = useState('')
    const [headache, setHeadache] = useState('')
    const [itching, setItching] = useState('')
    const [fever, setFever] = useState('')
    const [urinating_less, setUrinating_less] = useState('')
    const [blood_in_urine, setBlood_in_urine] = useState('')
    const [urine_color_change, setUrine_color_change] = useState('')
    const [blood_pressure, setBlood_pressure] = useState('')
    const [blood_sugar, setBlood_sugar] = useState('')
    const [weight_gain, setWeight_gain] = useState('')
    const [ankle_swelling, setAnkle_swelling] = useState('')
    const [Pain, setPain] = useState('')
    const [tired, setTired] = useState('')
    const [difficulties_sleeping, setDifficulties_sleeping] = useState('')
    const [fatigue, setFatigue] = useState('')
    const [eye_color, setEye_color] = useState('')
    const [loss_of_appetite, setLoss_of_appetite] = useState('')
    const [difficulty_breathing, setDifficulty_breathing] = useState('')
    const [userData, setUserData] = useState(null);

    useEffect(() => {
        // loadUser();
      }, []);

    const handleSubmit = (e) => {
        e.preventDefault();

        console.log(Gender)
        console.log(TimeDu)
        console.log(Flu)
        console.log(chills)
        console.log(Body_aches)
        console.log(dizziness)
        console.log(headache)
        console.log(itching)
        console.log(fever)
        console.log(urinating_less)
        console.log(blood_in_urine)
        console.log(urine_color_change)
        console.log(blood_pressure)
        console.log(blood_sugar)
        console.log(weight_gain)
        console.log(ankle_swelling)
        console.log(Pain)
        console.log(tired)
        console.log(difficulties_sleeping)
        console.log(fatigue)
        console.log(eye_color)
        console.log(loss_of_appetite)
        console.log(difficulty_breathing)

        let data = {
            Gender,
            TimeDu,
            Flu,
            chills,
            Body_aches,
            dizziness,
            headache,
            itching,
            fever,
            urinating_less,
            blood_in_urine,
            urine_color_change,
            blood_pressure,
            blood_sugar,
            weight_gain,
            ankle_swelling,
            Pain,
            tired,
            difficulties_sleeping,
            fatigue,
            eye_color,
            loss_of_appetite,
            difficulty_breathing
        }

        data.page = 'ktm'

        let requestBody = new FormData()

        requestBody.append('Gender', Gender)
        requestBody.append('TimeDu', TimeDu)
        requestBody.append('Flu', Flu)
        requestBody.append('chills', chills)
        requestBody.append('Body_aches', Body_aches)
        requestBody.append('dizziness', dizziness)
        requestBody.append('headache', headache)
        requestBody.append('itching', itching)
        requestBody.append('fever', fever)
        requestBody.append('urinating_less', urinating_less)
        requestBody.append('blood_in_urine', blood_in_urine)
        requestBody.append('urine_color_change', urine_color_change)
        requestBody.append('blood_pressure', blood_pressure)
        requestBody.append('blood_sugar', blood_sugar)
        requestBody.append('weight_gain', weight_gain)
        requestBody.append('ankle_swelling', ankle_swelling)
        requestBody.append('Pain', Pain)
        requestBody.append('tired', tired)
        requestBody.append('difficulties_sleeping', difficulties_sleeping)
        requestBody.append('fatigue', fatigue)
        requestBody.append('eye_color', eye_color)
        requestBody.append('loss_of_appetite', loss_of_appetite)
        requestBody.append('difficulty_breathing', difficulty_breathing)



        axios.post(`${apiUrl}/api/v1/ktm/transplant`, requestBody, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        }).then((response) => {
            console.log(response)
            console.log(response.data)
            data.result = response.data;
            // console.log(data)
            setReportData(data)
            history.push('/reportviewfour')
        }).catch((err) => {
            console.log(err)
        });
    };

    const loadUser = async () => {
        fetch(
          `${process.env.REACT_APP_HOSTING_URL}/users/latest-ckd-prediction/` +
            Auth.getUserId(),
          {
            method: 'GET',
            headers: new Headers({
              Accept: 'application/vnd.github.cloak-preview',
              token: Auth.getToken(),
            }),
          }
        )
          .then((res) => res.json())
          .then((response) => {
            console.log(response);
            setUserData(response);
          })
          .catch((error) => console.log(error));
      };

    return (
        <>
            {/* <!-- Breadcrumb --> */}
            <div className="breadcrumb-bar">
                <div className="container-fluid">
                    <div className="row align-items-center">
                        <div className="col-md-12 col-12">
                            <nav aria-label="breadcrumb" className="page-breadcrumb">
                                <ol className="breadcrumb">
                                    <li className="breadcrumb-item">
                                        <a href="/home">Home</a>
                                    </li>
                                    <li className="breadcrumb-item active" aria-current="page">
                                        Blank Page
                                    </li>
                                </ol>
                            </nav>
                            <h2 className="breadcrumb-title">Blank Page</h2>
                        </div>
                    </div>
                </div>
            </div>
            {/* <!-- /Breadcrumb -->    */}

            {/* <!-- Page Content --> */}
            <div className="content">
                <>
                    {/* <!-- Breadcrumb --> */}

                    <div className="breadcrumb-bar">
                        <div className="container-fluid">
                            <div className="row align-items-center">
                                <div className="col-md-12 col-12">
                                    <nav aria-label="breadcrumb" className="page-breadcrumb">
                                        <ol className="breadcrumb">
                                            <li className="breadcrumb-item">
                                                <a href="/home">Home</a>
                                            </li>
                                            <li className="breadcrumb-item active" aria-current="page">
                                                Risk Analysis and Prediction
                                            </li>
                                        </ol>
                                    </nav>
                                    <h2 className="breadcrumb-title">Kidney Transplant</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* <!-- /Breadcrumb -->    */}
                </>
                <div className="container-fluid">

                    <div className="row">
                        <div className="col-md-8" style={{ marginLeft: "18%" }}>
                            <div className="card">
                                <form action="#">
                                    <div className="card">

                                        <div className="card-header text-center">
                                            <div className="alert alert-success alert-dismissible fade show" role="alert">

                                                <strong>Information</strong>


                                            </div>

                                        </div>

                                        <div className="card-body">

                                            <div className="row">
                                                <div className="col-xl-6" style={{ flex: 'unset', maxWidth: 'unset' }}>

                                                    <div className="form-group row">
                                                        <label className="col-lg-3 col-form-label">
                                                            Gender
                                                        </label>
                                                        <div className="col-lg-9">
                                                            <div className="form-check form-check-inline" >
                                                                <input
                                                                    className="form-check-input"
                                                                    type="radio"
                                                                    name="gender"
                                                                    id="gender_male"
                                                                    value="Male"
                                                                    onChange={(e) => setGender(e.target.value)}
                                                                />
                                                                <label
                                                                    className="form-check-label"
                                                                    for="gender_male"
                                                                >
                                                                    Male
                                                                </label>
                                                            </div>
                                                            <div className="form-check form-check-inline">
                                                                <input
                                                                    className="form-check-input"
                                                                    type="radio"
                                                                    name="gender"
                                                                    id="gender_female"
                                                                    value="Female"
                                                                    onChange={(e) => setGender(e.target.value)}
                                                                />
                                                                <label
                                                                    className="form-check-label"
                                                                    for="gender_female"
                                                                >
                                                                    Female
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>



                                                    <div className="form-group row">
                                                        <label className="col-lg-3 col-form-label" style={{ maxWidth: '50%', flex: 'unset' }}>
                                                            How long has it been since the kidney transplant?
                                                        </label>
                                                        <div className="col-lg-9" style={{ maxWidth: '50%' }}>
                                                            <select className="form-control" onChange={(e) => setTimeDu(e.target[e.target.selectedIndex].text)}>
                                                                <option>-- Select --</option>
                                                                <option value="0">Below 1 month</option>
                                                                <option value="1">1 - 3 months</option>
                                                                <option value="2">4 - 6 months</option>
                                                                <option value="3">Above 6 months</option>
                                                                <option value="4">Above 1 year</option>
                                                                <option value="5">Above 3 years</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div className="form-group row">
                                                        <label className="col-lg-3 col-form-label" style={{ maxWidth: '50%', flex: 'unset' }}>
                                                            Blood pressure level(Systolic mm Hg)
                                                        </label>
                                                        <div className="col-lg-9" style={{ maxWidth: '50%' }}>
                                                            <select className="form-control" onChange={(e) => setBlood_pressure(e.target[e.target.selectedIndex].text)}>
                                                                <option>-- Select --</option>
                                                                <option value="1">{`< 120 mm Hg`}</option>
                                                                <option value="2">120-129 mm Hg</option>
                                                                <option value="3">130-139 mm Hg</option>
                                                                <option value="4">140-159 mm Hg</option>
                                                                <option value="5">160-179 mm Hg</option>
                                                                <option value="6">{`>=180 mm Hg`}</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div className="form-group row">
                                                        <label className="col-lg-3 col-form-label" style={{ maxWidth: '50%', flex: 'unset' }}>
                                                            Blood Suger Level
                                                        </label>
                                                        <div className="col-lg-9" style={{ maxWidth: '50%' }}>
                                                            <select className="form-control" onChange={(e) => setBlood_sugar(e.target[e.target.selectedIndex].text)}>
                                                                <option>-- Select --</option>
                                                                <option value="0">{`Below 89 mg/dL`}</option>
                                                                <option value="1">90-115 mg/dL</option>
                                                                <option value="2">116-140 mg/dL</option>
                                                                <option value="3">{`>140 mg/dL`}</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div className="form-group row">
                                                        <label className="col-lg-3 col-form-label" style={{ maxWidth: '50%', flex: 'unset' }}>
                                                            Changes of eye color
                                                        </label>
                                                        <div className="col-lg-9" style={{ maxWidth: '50%' }}>
                                                            <select className="form-control" onChange={(e) => setEye_color(e.target[e.target.selectedIndex].text)}>
                                                                <option>-- Select --</option>
                                                                <option value="0">
                                                                    Pale color
                                                                </option>
                                                                <option value="1">
                                                                    Normal color
                                                                </option>
                                                                <option value="2">
                                                                    Red color
                                                                </option>

                                                            </select>
                                                        </div>
                                                    </div>



                                                    <div className="form-group row">
                                                        <label className="col-lg-3 col-form-label" style={{ maxWidth: '50%', flex: 'unset' }}>
                                                            Have you feel like flu?
                                                        </label>
                                                        <div className="col-lg-9" style={{ maxWidth: '50%' }}>
                                                            <select className="form-control" onChange={(e) => setFlu(e.target[e.target.selectedIndex].text)}>
                                                                <option>-- Select --</option>
                                                                <option value="0">Yes</option>
                                                                <option value="1">No</option>
                                                                <option value="2">Maybe</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div className="col-xl-6" style={{ flex: 'unset', maxWidth: 'unset' }}>





                                                    <div className="form-group row">
                                                        <label className="col-lg-3 col-form-label" style={{ maxWidth: '50%', flex: 'unset' }}>
                                                            Is there pain or tenderness over the area where the kidney transplant was done?
                                                        </label>
                                                        <div className="col-lg-9" style={{ maxWidth: '50%' }}>
                                                            <select className="form-control " onChange={(e) => setPain(e.target[e.target.selectedIndex].text)}>
                                                                <option value="0">-- Select --</option>
                                                                <option value="1"> Yes</option>
                                                                <option value="2">No</option>
                                                                <option value="3">Maybe</option>

                                                            </select>
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="card">

                                        <div className="card-header text-center">
                                            <div className="alert alert-primary alert-dismissible fade show" role="alert">

                                                <strong>Symptoms Related Information</strong>

                                            </div>

                                        </div>

                                        <div className="card-body">

                                            <div className="row">
                                                {/* <!-- Invoice Item --> */}
                                                <div className="col-md-12 text-center">
                                                    <div className="invoice-item invoice-table-wrap">
                                                        <div className="row">
                                                            <div className="col-md-12">
                                                                <div className="table-responsive">
                                                                    <table className="invoice-table table table-bordered">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>Description</th>
                                                                                <th>Yes</th>
                                                                                <th>No</th>

                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td> Have you feel like chills?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="home"
                                                                                        id="home-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setChills(e.target.value)}
                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="home"
                                                                                        id="home-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setChills(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Do you have Body aches?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="sleep"
                                                                                        id="sleep-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setBody_aches(e.target.value)}
                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="sleep"
                                                                                        id="sleep-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setBody_aches(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Do you have dizziness?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="skin"
                                                                                        id="skin-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setDizziness(e.target.value)}
                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="skin"
                                                                                        id="skin-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setDizziness(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Do you have a headache?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="urine"
                                                                                        id="urine-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setHeadache(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="urine"
                                                                                        id="urine-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setHeadache(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td> Do you have frequent itching in the skin?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="foaming"
                                                                                        id="foaming-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setItching(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="foaming"
                                                                                        id="foaming-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setItching(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Do you have a fever of 101°F or higher?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="eyes"
                                                                                        id="eyes-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setFever(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="eyes"
                                                                                        id="eyes-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setFever(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Is the urinating less than usual?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="appetite"
                                                                                        id="appetite-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setUrinating_less(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="appetite"
                                                                                        id="appetite-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setUrinating_less(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td> Is there blood in the urine?{" "}</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="cramps"
                                                                                        id="cramps-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setBlood_in_urine(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="cramps"
                                                                                        id="cramps-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setBlood_in_urine(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Is there a change in the color of the urine?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="filtered"
                                                                                        id="filtered-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setUrine_color_change(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="filtered"
                                                                                        id="filtered-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setUrine_color_change(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Was there a sudden weight gain?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="itching"
                                                                                        id="itching-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setWeight_gain(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="itching"
                                                                                        id="itching-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setWeight_gain(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>  Are there ankle swelling?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="urination"
                                                                                        id="urination-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setAnkle_swelling(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="urination"
                                                                                        id="urination-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setAnkle_swelling(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>  Have you feel very tired?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="chemicals"
                                                                                        id="chemicals-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setTired(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="chemicals"
                                                                                        id="chemicals-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setTired(e.target.value)}

                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Do you have difficulties sleeping?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="pain"
                                                                                        id="pain-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setDifficulties_sleeping(e.target.value)}


                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="pain"
                                                                                        id="pain-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setDifficulties_sleeping(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>
                                                                            <tr>
                                                                                <td>Do you have fatigue?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="eye-color"
                                                                                        id="eye-color-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setFatigue(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="eye-color"
                                                                                        id="eye-color-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setFatigue(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>

                                                                            <tr>
                                                                                <td>Do you have a loss of appetite?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="loss-appetite"
                                                                                        id="loss-appetite-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setLoss_of_appetite(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="loss-appetite"
                                                                                        id="loss-appetite-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setLoss_of_appetite(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>

                                                                            <tr>
                                                                                <td>Do you have shortness of breath or difficulty breathing?</td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline text-center">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="diff-breathing"
                                                                                        id="diff-breathing-y"
                                                                                        value="Yes"
                                                                                        onChange={(e) => setDifficulty_breathing(e.target.value)}

                                                                                    />

                                                                                </div></td>
                                                                                <td className="text-center"> <div className="form-check form-check-inline">
                                                                                    <input
                                                                                        className="form-check-input"
                                                                                        type="radio"
                                                                                        name="diff-breathing"
                                                                                        id="diff-breathing-n"
                                                                                        value="No"
                                                                                        onChange={(e) => setDifficulty_breathing(e.target.value)}
                                                                                    />

                                                                                </div></td>

                                                                            </tr>

                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                            <br></br>

                                                        </div>


                                                    </div>

                                                </div>
                                                {/* <!-- /Invoice Item --> */}




                                            </div>
                                        </div>
                                        <div className="col-6 col-sm-4 col-md-2 col-xl mb-3 mb-xl-0 text-right">
                                            {/* <Link to="/reportview"> */}
                                            <button type="submit" className="btn btn-outline-primary active" far icon="paper-plane" onClick={(e) => handleSubmit(e)}>
                                                Genarate Status Report
                                            </button>
                                            {/* </Link> */}
                                        </div>
                                    </div>



                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
