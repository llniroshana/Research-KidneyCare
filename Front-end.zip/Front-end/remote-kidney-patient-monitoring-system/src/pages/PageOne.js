import React, { useState,useEffect } from "react";
import Auth from "../authentication/Auth";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
  Link,
  useHistory
} from "react-router-dom";
import axios from "axios";

export default function PageOne(params) {
  const history = useHistory();
  const { setReportData } = params;
  const apiUrl = process.env.REACT_APP_BACKEND;
  const [province, setProvince] = useState('')
  const [ageGroup, setAgeGroup] = useState('')
  const [gender, setGender] = useState('')
  const [bloodGroup, setBloodGroup] = useState('')
  const [bloodSugarLevel, setBloodSugarLevel] = useState('')
  const [bloodPresureLevel, setBloodPresureLevel] = useState('')
  const [resource, setResource] = useState('')
  const [alcohol, setAlcohol] = useState('')
  const [field, setField] = useState('')
  const [sleep, setSleep] = useState('')
  const [skin, setSkin] = useState('')
  const [urine, setUrine] = useState('')
  const [forming, setForming] = useState('')
  const [eyes, setEyes] = useState('')
  const [appatite, setAppatite] = useState('')
  const [cramps, setCramps] = useState('')
  const [filter, setFilter] = useState('')
  const [itching, setItching] = useState('')
  const [urination, setUrination] = useState('')
  const [chemicals, setChemicals] = useState('')
  const [pain, setPain] = useState('')
  const [eyecolour, setEyecolour] = useState('')
  const [userData, setUserData] = useState(null)

  useEffect(() => {
    loadUser();
  }, [])
  const handleSubmit = (e) => {
    e.preventDefault();

    let data = {
      province,
      ageGroup,
      gender,
      bloodGroup,
      bloodSugarLevel,
      bloodPresureLevel,
      resource,
      alcohol,
      field,
      sleep,
      skin,
      urine,
      forming,
      eyes,
      appatite,
      cramps,
      filter,
      itching,
      urination,
      chemicals,
      pain,
      eyecolour
    }

    data.page = 'ckd'

    let requestBody = new FormData()

    requestBody.append('province', province)
    requestBody.append('ageGroup', ageGroup)
    requestBody.append('gender', gender)
    requestBody.append('resource', resource)
    requestBody.append('field', field)
    requestBody.append('bloodSugarLevel', bloodSugarLevel)
    requestBody.append('bloodPresureLevel', bloodPresureLevel)
    requestBody.append('sleep', sleep)
    requestBody.append('skin', skin)
    requestBody.append('urine', urine)
    requestBody.append('forming', forming)
    requestBody.append('eyes', eyes)
    requestBody.append('appatite', appatite)
    requestBody.append('cramps', cramps)
    requestBody.append('filter', filter)
    requestBody.append('itching', itching)
    requestBody.append('urination', urination)
    requestBody.append('alcohol', alcohol)
    requestBody.append('chemicals', chemicals)
    requestBody.append('pain', pain)
    requestBody.append('eyecolour', eyecolour)


    axios.post(`${apiUrl}/api/v1/ckd/critical`, requestBody, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    }).then((response) => {
      console.log(response)
      console.log(response.data)
      data.result = response.data;
      // console.log(data)
      setReportData(data)
      history.push('/reportview')
    }).catch((err) => {
      console.log(err)
    })
  }

  const loadUser = async () => {
    fetch(`${process.env.REACT_APP_HOSTING_URL}/users/latest-ckd-prediction/` + Auth.getUserId(), {
      method: "GET",
      headers: new Headers({
        Accept: "application/vnd.github.cloak-preview",
        token: Auth.getToken(),
      }),
    })
      .then((res) => res.json())
      .then((response) => {
        console.log(response);
        setUserData(response);
       // if(response.ageGroup!=null){}

          setProvince(response.province); 
          setAgeGroup(response.ageGroup);
          setGender(response.gender);
          setBloodSugarLevel(response.bloodSugarLevel);
          setBloodPresureLevel(response.bloodPresureLevel);
          setResource(response.resource);
          setAlcohol(response.alcohol);
          setField(response.field);
          setSkin(response.skin);
          setUrine(response.urine);
          setForming(response.forming);
          setEyes(response.eyes);
          setAppatite(response.appatite);
          setCramps(response.cramps);
          setFilter(response.filter);
          setItching(response.itching);
          setUrination(response.urination);
          setChemicals(response.chemicals);
          setPain(response.pain);
          setEyes(response.eyecolour);
          
        
          
        // document.getElementsByName("province")[0].value = response.provinces;
        // if(response.user_data.age_group!=null)
        // document.getElementsByName("Age")[0].value = response.user_data.age_group;
        // if(response.user_data.marital_stat!=null)
        // document.getElementsByName("Marital Status")[0].value = response.user_data.marital_stat;
        // if(response.user_data.ethnacity!=null)
        // document.getElementsByName("Ethnicity")[0].value = response.user_data.ethnacity;
        // if(response.user_data.hometown!=null)
        // document.getElementsByName("Home Town")[0].value = response.user_data.hometown;
        // if(response.user_data.al_stream!=null)
        // document.getElementsByName("A/L Stream")[0].value = response.user_data.al_stream;
        // if(response.user_data.sub_1!=null)
        // document.getElementsByName("Subject_1")[0].value = response.user_data.sub_1;
        // if(response.user_data.res_1!=null)
        // document.getElementsByName("Result_1")[0].value = response.user_data.res_1;
        // if(response.user_data.sub_2!=null)
        // document.getElementsByName("Subject_2")[0].value = response.user_data.sub_2;
        // if(response.user_data.res_2!=null)
        // document.getElementsByName("Result_2")[0].value = response.user_data.res_2;
        // if(response.user_data.sub_3!=null)
        // document.getElementsByName("Subject_3")[0].value = response.user_data.sub_3;
        // if(response.user_data.res_3!=null)
        // document.getElementsByName("Result_3")[0].value = response.user_data.res_3;
        // if(response.user_data.univercity!=null)
        // document.getElementsByName("Univesity/Degree Awarding Institute")[0].value = response.user_data.univercity;
        // if(response.user_data.degree!=null)
        // document.getElementsByName("Degree")[0].value = response.user_data.degree;
        // if(response.user_data.duration!=null)
        // document.getElementsByName("Duration Of Degree")[0].value = response.user_data.duration;
        // if(response.user_data.grad_year!=null)
        // document.getElementsByName("Graduation Year")[0].value = response.user_data.grad_year;
        // if(response.user_data.gpa!=null)
        // document.getElementsByName("GPA")[0].value = response.user_data.gpa;

      })
      .catch((error) => console.log(error));
  };

 

  return (
    <>
      {/* <!-- Breadcrumb --> */}
      <div className="breadcrumb-bar">
        <div className="container-fluid">
          <div className="row align-items-center">
            <div className="col-md-12 col-12">
              <nav aria-label="breadcrumb" className="page-breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <a href="/home">Home</a>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Blank Page
                  </li>
                </ol>
              </nav>
              <h2 className="breadcrumb-title">Blank Page</h2>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- /Breadcrumb -->    */}

      {/* <!-- Page Content --> */}
      <div className="content">
        <>
          {/* <!-- Breadcrumb --> */}

          <div className="breadcrumb-bar">
            <div className="container-fluid">
              <div className="row align-items-center">
                <div className="col-md-12 col-12">
                  <nav aria-label="breadcrumb" className="page-breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <a href="/home">Home</a>
                      </li>
                      <li className="breadcrumb-item active" aria-current="page">
                        Risk Analysis and Prediction
                      </li>
                    </ol>
                  </nav>
                  <h2 className="breadcrumb-title">Area</h2>
                </div>
              </div>
            </div>
          </div>
          {/* <!-- /Breadcrumb -->    */}
        </>
        <div className="container-fluid">

          <div className="row">
            <div className="col-md-8" style={{ marginLeft: "18%" }}>
              <div className="card">
                <form action="#">
                  <div className="card">

                    <div className="card-header text-center">
                      <div className="alert alert-success alert-dismissible fade show" role="alert">

                        <strong>Personal Information </strong>


                      </div>

                    </div>

                    <div className="card-body">

                      <div className="row">
                        <div className="col-xl-6">
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Province
                            </label>
                            <div className="col-lg-9">
                              <select name="province" className="form-control" value={province} onChange={(e) => setProvince(e.target.value)}>
                                <option>-- Select --</option>
                                <option value="0">North Central</option>
                                <option value="1">North Western</option>
                                <option value="2">Eastern </option>
                                <option value="3">Uva </option>
                                <option value="4">North </option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Age Group
                            </label>
                            <div className="col-lg-9">
                              <select className="form-control" value={ageGroup} onChange={(e) => setAgeGroup(e.target.value)}>
                                <option>-- Select  --</option>
                                <option value="1">10-19 </option>
                                <option value="2">20-29 </option>
                                <option value="3">30-39 </option>
                                <option value="4">40-49</option>
                                <option value="5">50-59</option>
                                <option value="6">60+</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Gender
                            </label>
                            <div className="col-lg-9">
                              <div className="form-check form-check-inline" >
                                <input
                                  className="form-check-input"
                                  type="radio"
                                  name="gender"
                                  id="gender_male"
                                  checked = {gender === 'Male'}
                                  value="Male"
                                  onChange={(e) => setGender(e.target.value)}
                                />
                                <label
                                  className="form-check-label"
                                  for="gender_male"
                                >
                                  Male
                                </label>
                              </div>
                              <div className="form-check form-check-inline">
                                <input
                                  className="form-check-input"
                                  type="radio"
                                  name="gender"
                                  checked = {gender === 'Female'}
                                  id="gender_female"
                                  value="Female"
                                  onChange={(e) => setGender(e.target.value)}
                                />
                                <label
                                  className="form-check-label"
                                  for="gender_female"
                                >
                                  Female
                                </label>
                              </div>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Alchol Usage
                            </label>
                            <div className="col-lg-9">
                              <select className="form-control"  value={alcohol} onChange={(e) => setAlcohol(e.target.value)}>
                                <option>-- Select --</option>
                                <option value="0">Addicted</option>
                                <option value="1">Occasional</option>
                                <option value="2">Never</option>
                              </select>
                            </div>
                          </div>

                        </div>
                        <div className="col-xl-6">
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Blood Suger Level
                            </label>
                            <div className="col-lg-9">
                              <select className="form-control" value={bloodSugarLevel} onChange={(e) => setBloodSugarLevel(e.target.value)}>
                                <option>-- Select --</option>
                                <option value="0">Below 89 mg/dL</option>
                                <option value="1">90 -120 mg/dL</option>
                                <option value="2">121-139 mg/dL</option>
                                <option value="3">140mg/dL+</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Blood Pressure Level
                            </label>
                            <div className="col-lg-9">
                              <select className="form-control " value={bloodPresureLevel} onChange={(e) => setBloodPresureLevel(e.target.value)}>
                                <option value="0">-- Select --</option>
                                <option value="1"> 120 mm Hg</option>
                                <option value="2">120 - 139 mm Hg</option>
                                <option value="3">140 - 159 mm Hg</option>
                                <option value="4">160 - 179 mm Hg</option>
                                <option value="5">180 mm Hg+</option>
                              </select>
                            </div>
                          </div>
                          <div className="form-group row">
                            <label className="col-lg-3 col-form-label">
                              Water Resource
                            </label>
                            <div className="col-lg-9">
                              <select className="form-control" value={resource} onChange={(e) => setResource(e.target.value)}>
                                <option>-- Select --</option>
                                <option value="0">
                                  By direct from the Well, River , Lake
                                </option>
                                <option value="1">
                                  Water providing by government (water line)
                                </option>
                                <option value="2">
                                  Purified bottle water (From market)
                                </option>
                                <option value="3">Tube well</option>
                              </select>
                            </div>
                          </div>

                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="card">

                    <div className="card-header text-center">
                      <div className="alert alert-primary alert-dismissible fade show" role="alert">

                        <strong>Symptoms Related Information</strong>

                      </div>

                    </div>

                    <div className="card-body">

                      <div className="row">
                        {/* <!-- Invoice Item --> */}
                        <div className="col-md-12 text-center">
                          <div className="invoice-item invoice-table-wrap">
                            <div className="row">
                              <div className="col-md-12">
                                <div className="table-responsive">
                                  <table className="invoice-table table table-bordered">
                                    <thead>
                                      <tr>
                                        <th>Description</th>
                                        <th>Yes</th>
                                        <th>No</th>

                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td> Is your home situated near to the paddy fields?</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="home"
                                            id="home-y"
                                            value="1"
                                            onChange={(e) => setField(e.target.value)}
                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="home"
                                            id="home-n"
                                            value="0"
                                            onChange={(e) => setField(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td>Do you have Sleeping problems ?</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="sleep"
                                            id="sleep-y"
                                            value="1"
                                            onChange={(e) => setSleep(e.target.value)}
                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="sleep"
                                            id="sleep-n"
                                            value="0"
                                            onChange={(e) => setSleep(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td>Dry nature of the skin</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="skin"
                                            id="skin-y"
                                            value="1"
                                            onChange={(e) => setSkin(e.target.value)}
                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="skin"
                                            id="skin-n"
                                            value="0"
                                            onChange={(e) => setSkin(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td>Do you Bleed with urine(Lightly)</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="urine"
                                            id="urine-y"
                                            value="Yes"
                                            onChange={(e) => setUrine(e.target.value)}

                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="urine"
                                            id="urine-n"
                                            value="No"
                                            onChange={(e) => setUrine(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td> Foaming while urinating</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="foaming"
                                            id="foaming-y"
                                            value="1"
                                            onChange={(e) => setForming(e.target.value)}

                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="foaming"
                                            id="foaming-n"
                                            value="0"
                                            onChange={(e) => setForming(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td>Persistent swelling around the eyes</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="eyes"
                                            id="eyes-y"
                                            value="1"
                                            onChange={(e) => setEyes(e.target.value)}

                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="eyes"
                                            id="eyes-n"
                                            value="0"
                                            onChange={(e) => setEyes(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td>Decreased appetite </td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="appetite"
                                            id="appetite-y"
                                            value="Yes"
                                            onChange={(e) => setAppatite(e.target.value)}

                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="appetite"
                                            id="appetite-n"
                                            value="No"
                                            onChange={(e) => setAppatite(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td> Do you have frequently muscle cramps or muscle twitches{" "}</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="cramps"
                                            id="cramps-y"
                                            value="1"
                                            onChange={(e) => setCramps(e.target.value)}

                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="cramps"
                                            id="cramps-n"
                                            value="0"
                                            onChange={(e) => setCramps(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td>Usage of filtered and boiled water</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="filtered"
                                            id="filtered-y"
                                            value="1"
                                            onChange={(e) => setFilter(e.target.value)}

                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="filtered"
                                            id="filtered-n"
                                            value="0"
                                            onChange={(e) => setFilter(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td>Is there a frequent itching in your skin</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="itching"
                                            id="itching-y"
                                            value="1"
                                            onChange={(e) => setItching(e.target.value)}

                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="itching"
                                            id="itching-n"
                                            value="0"
                                            onChange={(e) => setItching(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td>  Do you have frequent urination necessary</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="urination"
                                            id="urination-y"
                                            value="1"
                                            onChange={(e) => setUrination(e.target.value)}

                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="urination"
                                            id="urination-n"
                                            value="0"
                                            onChange={(e) => setUrination(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td>  Do you have a direct connect with agricultural
                                          chemicals ?</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="chemicals"
                                            id="chemicals-y"
                                            value="1"
                                            onChange={(e) => setChemicals(e.target.value)}

                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="chemicals"
                                            id="chemicals-n"
                                            value="0"
                                            onChange={(e) => setChemicals(e.target.value)}

                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td>Do you have pain around your kidneys</td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="pain"
                                            id="pain-y"
                                            value="1"
                                            onChange={(e) => setPain(e.target.value)}


                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="pain"
                                            id="pain-n"
                                            value="0"
                                            onChange={(e) => setPain(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>
                                      <tr>
                                        <td>Change of eye color (Light yellow) </td>
                                        <td className="text-center"> <div className="form-check form-check-inline text-center">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="eye-color"
                                            id="eye-color-y"
                                            value="1"
                                            onChange={(e) => setEyecolour(e.target.value)}

                                          />

                                        </div></td>
                                        <td className="text-center"> <div className="form-check form-check-inline">
                                          <input
                                            className="form-check-input"
                                            type="radio"
                                            name="eye-color"
                                            id="eye-color-n"
                                            value="0"
                                            onChange={(e) => setEyecolour(e.target.value)}
                                          />

                                        </div></td>

                                      </tr>

                                    </tbody>
                                  </table>
                                </div>
                              </div>
                              <br></br>

                            </div>


                          </div>

                        </div>
                        {/* <!-- /Invoice Item --> */}




                      </div>
                    </div>
                    <div className="col-6 col-sm-4 col-md-2 col-xl mb-3 mb-xl-0 text-right">
                      {/* <Link to="/ReportViewDulitha"> */}
                      <button type="submit" className="btn btn-outline-primary active" far icon="paper-plane" onClick={(e) => handleSubmit(e)}>
                        Genarate Status Report
                      </button>
                      {/* </Link> */}
                    </div>
                  </div>



                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
