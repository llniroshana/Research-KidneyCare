import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import {
    BrowserRouter as Router,
    Route,
    Switch,
    Redirect,
    Link,
} from "react-router-dom";

export default function Login() {
    const [error, setError] = useState("");
    const [redirect, setRedirect] = useState(false);
    const {
        register,
        handleSubmit,
        watch,
        setValue,
        formState: { errors },
    } = useForm({
        name: "",
        email: "",
        phone: "",
        sector: "",
        workplace: "",
        password: "",
    });

    useEffect(() => {
        console.log();
    }, []);
    const login = async (event) => {
        console.log(event);

        try {
            const requestOptions = {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    email: event.email,
                    password: event.password,
                }),
            };
            const res = await fetch(
                `${process.env.REACT_APP_HOSTING_URL}/users/login`,
                requestOptions
            );

            const data = await res.json();

            if (data.hasOwnProperty("accessToken")) {
                localStorage.setItem("token", data.accessToken);
                setRedirect(true);
            } else {
                setError(data.error);
            }
        } catch (e) {
            console.log(e);
        }
    };
    if (redirect) {
        return <Redirect to="/" />;
    }
    return (
        <>
            {/* <!-- Breadcrumb --> */}
            <div class="breadcrumb-bar">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-md-12 col-12">
                            <nav aria-label="breadcrumb" class="page-breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="/home">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        
                                    </li>
                                </ol>
                            </nav>
                            <h2 class="breadcrumb-title">Login</h2>
                        </div>
                    </div>
                </div>
            </div>
            {/* <!-- /Breadcrumb -->    */}

            <div class="content">
                <>
                    {/* <!-- Breadcrumb --> */}
                    <div class="breadcrumb-bar">
                        <div class="container-fluid">
                            <div class="row align-items-center">
                                <div class="col-md-12 col-12">
                                    <nav aria-label="breadcrumb" class="page-breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="/home">Home</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">
                                             
                                            </li>
                                        </ol>
                                    </nav>
                                    <h2 class="breadcrumb-title">Login</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* <!-- /Breadcrumb -->    */}
                </>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8 offset-md-2">
                            {/* <!-- Login Tab Content --> */}
                            <div class="account-content">
                                <div class="row align-items-center justify-content-center">
                                    <div class="col-md-7 col-lg-6 login-left">
                                        <img
                                            src="assets/img/CKD1.jpg"
                                            class="img-fluid"
                                            alt="Docucare Login"
                                        />
                                    </div>
                                    <div class="col-md-12 col-lg-6 login-right">
                                        <div class="login-header">
                                            <h3>
                                                Login <span>Kidney Care</span>
                                            </h3>
                                        </div>
                                        {error != "" ? (
                                            <div className="alert alert-danger" role="alert">
                                                {error}
                                            </div>
                                        ) : null}
                                        <form onSubmit={handleSubmit(login)}>
                                            <div class="form-group form-focus">
                                                <input
                                                    type="email"
                                                    {...register("email", {
                                                        required: true,
                                                    })}
                                                    class="form-control floating"
                                                />
                                                <label class="focus-label">Email</label>
                                                {errors.name && <span className="text-danger">This field is required</span>}
                                            </div>
                                            <div class="form-group form-focus">
                                                <input type="password" class="form-control floating"
                                                    {...register("password", {
                                                        required: true,
                                                    })}
                                                />
                                                <label class="focus-label">Password</label>
                                                {errors.password && <span className="text-danger">This field is required</span>}
                                            </div>
                                            <div class="text-right">
                                                <a class="forgot-link" href="forgot-password.html">
                                                    Forgot Password ?
                                                </a>
                                            </div>
                                            <button
                                                class="btn btn-primary btn-block btn-lg login-btn"
                                                type="submit"
                                            >
                                                Login
                                            </button>
                                            <div class="login-or">
                                                <span class="or-line"></span>
                                                <span class="span-or">or</span>
                                            </div>
                                            <div class="row form-row social-login">
                                                <div class="col-6">
                                                    <a href="#" class="btn btn-facebook btn-block">
                                                        <i class="fab fa-facebook-f mr-1"></i> Login
                                                    </a>
                                                </div>
                                                <div class="col-6">
                                                    <a href="#" class="btn btn-google btn-block">
                                                        <i class="fab fa-google mr-1"></i> Login
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="text-center dont-have">
                                                Don’t have an account? <a href="/register">Register</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            {/* <!-- /Login Tab Content --> */}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
